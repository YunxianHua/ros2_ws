// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__MANUAL_CLEAN_CTRL_HPP_
#define CLEAN_MSGS__SRV__MANUAL_CLEAN_CTRL_HPP_

#include "clean_msgs/srv/detail/manual_clean_ctrl__struct.hpp"
#include "clean_msgs/srv/detail/manual_clean_ctrl__builder.hpp"
#include "clean_msgs/srv/detail/manual_clean_ctrl__traits.hpp"
#include "clean_msgs/srv/detail/manual_clean_ctrl__type_support.hpp"

#endif  // CLEAN_MSGS__SRV__MANUAL_CLEAN_CTRL_HPP_
