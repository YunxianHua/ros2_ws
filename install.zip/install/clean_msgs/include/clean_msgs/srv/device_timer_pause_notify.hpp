// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DEVICE_TIMER_PAUSE_NOTIFY_HPP_
#define CLEAN_MSGS__SRV__DEVICE_TIMER_PAUSE_NOTIFY_HPP_

#include "clean_msgs/srv/detail/device_timer_pause_notify__struct.hpp"
#include "clean_msgs/srv/detail/device_timer_pause_notify__builder.hpp"
#include "clean_msgs/srv/detail/device_timer_pause_notify__traits.hpp"
#include "clean_msgs/srv/detail/device_timer_pause_notify__type_support.hpp"

#endif  // CLEAN_MSGS__SRV__DEVICE_TIMER_PAUSE_NOTIFY_HPP_
