// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from clean_msgs:srv/HandDrawPathSave.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__HAND_DRAW_PATH_SAVE__STRUCT_H_
#define CLEAN_MSGS__SRV__DETAIL__HAND_DRAW_PATH_SAVE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'paths'
#include "clean_msgs/msg/detail/path_info__struct.h"

// Struct defined in srv/HandDrawPathSave in the package clean_msgs.
typedef struct clean_msgs__srv__HandDrawPathSave_Request
{
  clean_msgs__msg__PathInfo__Sequence paths;
} clean_msgs__srv__HandDrawPathSave_Request;

// Struct for a sequence of clean_msgs__srv__HandDrawPathSave_Request.
typedef struct clean_msgs__srv__HandDrawPathSave_Request__Sequence
{
  clean_msgs__srv__HandDrawPathSave_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} clean_msgs__srv__HandDrawPathSave_Request__Sequence;


// Constants defined in the message

// Struct defined in srv/HandDrawPathSave in the package clean_msgs.
typedef struct clean_msgs__srv__HandDrawPathSave_Response
{
  uint32_t result;
} clean_msgs__srv__HandDrawPathSave_Response;

// Struct for a sequence of clean_msgs__srv__HandDrawPathSave_Response.
typedef struct clean_msgs__srv__HandDrawPathSave_Response__Sequence
{
  clean_msgs__srv__HandDrawPathSave_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} clean_msgs__srv__HandDrawPathSave_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CLEAN_MSGS__SRV__DETAIL__HAND_DRAW_PATH_SAVE__STRUCT_H_
