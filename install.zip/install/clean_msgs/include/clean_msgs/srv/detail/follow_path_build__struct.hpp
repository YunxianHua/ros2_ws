// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from clean_msgs:srv/FollowPathBuild.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__FOLLOW_PATH_BUILD__STRUCT_HPP_
#define CLEAN_MSGS__SRV__DETAIL__FOLLOW_PATH_BUILD__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__clean_msgs__srv__FollowPathBuild_Request __attribute__((deprecated))
#else
# define DEPRECATED__clean_msgs__srv__FollowPathBuild_Request __declspec(deprecated)
#endif

namespace clean_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct FollowPathBuild_Request_
{
  using Type = FollowPathBuild_Request_<ContainerAllocator>;

  explicit FollowPathBuild_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->cmd = 0ul;
      this->path_type = 0ul;
      this->map_id = "";
      this->exec_id = "";
      this->name = "";
    }
  }

  explicit FollowPathBuild_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : map_id(_alloc),
    exec_id(_alloc),
    name(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->cmd = 0ul;
      this->path_type = 0ul;
      this->map_id = "";
      this->exec_id = "";
      this->name = "";
    }
  }

  // field types and members
  using _cmd_type =
    uint32_t;
  _cmd_type cmd;
  using _path_type_type =
    uint32_t;
  _path_type_type path_type;
  using _map_id_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _map_id_type map_id;
  using _exec_id_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _exec_id_type exec_id;
  using _name_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _name_type name;

  // setters for named parameter idiom
  Type & set__cmd(
    const uint32_t & _arg)
  {
    this->cmd = _arg;
    return *this;
  }
  Type & set__path_type(
    const uint32_t & _arg)
  {
    this->path_type = _arg;
    return *this;
  }
  Type & set__map_id(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->map_id = _arg;
    return *this;
  }
  Type & set__exec_id(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->exec_id = _arg;
    return *this;
  }
  Type & set__name(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->name = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint32_t FOLLOW_PATH_BUILD_START =
    1u;
  static constexpr uint32_t FOLLOW_PATH_BUILD_CANCEL =
    2u;
  static constexpr uint32_t FOLLOW_PATH_BUILD_SAVE =
    3u;
  static constexpr uint32_t PATH_TYPE_LINE =
    1u;
  static constexpr uint32_t PATH_TYPE_ZONE =
    2u;

  // pointer types
  using RawPtr =
    clean_msgs::srv::FollowPathBuild_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const clean_msgs::srv::FollowPathBuild_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<clean_msgs::srv::FollowPathBuild_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<clean_msgs::srv::FollowPathBuild_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::FollowPathBuild_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::FollowPathBuild_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::FollowPathBuild_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::FollowPathBuild_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<clean_msgs::srv::FollowPathBuild_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<clean_msgs::srv::FollowPathBuild_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__clean_msgs__srv__FollowPathBuild_Request
    std::shared_ptr<clean_msgs::srv::FollowPathBuild_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__clean_msgs__srv__FollowPathBuild_Request
    std::shared_ptr<clean_msgs::srv::FollowPathBuild_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const FollowPathBuild_Request_ & other) const
  {
    if (this->cmd != other.cmd) {
      return false;
    }
    if (this->path_type != other.path_type) {
      return false;
    }
    if (this->map_id != other.map_id) {
      return false;
    }
    if (this->exec_id != other.exec_id) {
      return false;
    }
    if (this->name != other.name) {
      return false;
    }
    return true;
  }
  bool operator!=(const FollowPathBuild_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct FollowPathBuild_Request_

// alias to use template instance with default allocator
using FollowPathBuild_Request =
  clean_msgs::srv::FollowPathBuild_Request_<std::allocator<void>>;

// constant definitions
template<typename ContainerAllocator>
constexpr uint32_t FollowPathBuild_Request_<ContainerAllocator>::FOLLOW_PATH_BUILD_START;
template<typename ContainerAllocator>
constexpr uint32_t FollowPathBuild_Request_<ContainerAllocator>::FOLLOW_PATH_BUILD_CANCEL;
template<typename ContainerAllocator>
constexpr uint32_t FollowPathBuild_Request_<ContainerAllocator>::FOLLOW_PATH_BUILD_SAVE;
template<typename ContainerAllocator>
constexpr uint32_t FollowPathBuild_Request_<ContainerAllocator>::PATH_TYPE_LINE;
template<typename ContainerAllocator>
constexpr uint32_t FollowPathBuild_Request_<ContainerAllocator>::PATH_TYPE_ZONE;

}  // namespace srv

}  // namespace clean_msgs


#ifndef _WIN32
# define DEPRECATED__clean_msgs__srv__FollowPathBuild_Response __attribute__((deprecated))
#else
# define DEPRECATED__clean_msgs__srv__FollowPathBuild_Response __declspec(deprecated)
#endif

namespace clean_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct FollowPathBuild_Response_
{
  using Type = FollowPathBuild_Response_<ContainerAllocator>;

  explicit FollowPathBuild_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->result = 0ul;
      this->exec_id = "";
      this->path_id = "";
    }
  }

  explicit FollowPathBuild_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : exec_id(_alloc),
    path_id(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->result = 0ul;
      this->exec_id = "";
      this->path_id = "";
    }
  }

  // field types and members
  using _result_type =
    uint32_t;
  _result_type result;
  using _exec_id_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _exec_id_type exec_id;
  using _path_id_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _path_id_type path_id;

  // setters for named parameter idiom
  Type & set__result(
    const uint32_t & _arg)
  {
    this->result = _arg;
    return *this;
  }
  Type & set__exec_id(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->exec_id = _arg;
    return *this;
  }
  Type & set__path_id(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->path_id = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    clean_msgs::srv::FollowPathBuild_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const clean_msgs::srv::FollowPathBuild_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<clean_msgs::srv::FollowPathBuild_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<clean_msgs::srv::FollowPathBuild_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::FollowPathBuild_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::FollowPathBuild_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::FollowPathBuild_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::FollowPathBuild_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<clean_msgs::srv::FollowPathBuild_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<clean_msgs::srv::FollowPathBuild_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__clean_msgs__srv__FollowPathBuild_Response
    std::shared_ptr<clean_msgs::srv::FollowPathBuild_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__clean_msgs__srv__FollowPathBuild_Response
    std::shared_ptr<clean_msgs::srv::FollowPathBuild_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const FollowPathBuild_Response_ & other) const
  {
    if (this->result != other.result) {
      return false;
    }
    if (this->exec_id != other.exec_id) {
      return false;
    }
    if (this->path_id != other.path_id) {
      return false;
    }
    return true;
  }
  bool operator!=(const FollowPathBuild_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct FollowPathBuild_Response_

// alias to use template instance with default allocator
using FollowPathBuild_Response =
  clean_msgs::srv::FollowPathBuild_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace clean_msgs

namespace clean_msgs
{

namespace srv
{

struct FollowPathBuild
{
  using Request = clean_msgs::srv::FollowPathBuild_Request;
  using Response = clean_msgs::srv::FollowPathBuild_Response;
};

}  // namespace srv

}  // namespace clean_msgs

#endif  // CLEAN_MSGS__SRV__DETAIL__FOLLOW_PATH_BUILD__STRUCT_HPP_
