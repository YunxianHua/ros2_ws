// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from clean_msgs:srv/ManualCleanCtrl.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__MANUAL_CLEAN_CTRL__BUILDER_HPP_
#define CLEAN_MSGS__SRV__DETAIL__MANUAL_CLEAN_CTRL__BUILDER_HPP_

#include "clean_msgs/srv/detail/manual_clean_ctrl__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_ManualCleanCtrl_Request_post_stop_type
{
public:
  explicit Init_ManualCleanCtrl_Request_post_stop_type(::clean_msgs::srv::ManualCleanCtrl_Request & msg)
  : msg_(msg)
  {}
  ::clean_msgs::srv::ManualCleanCtrl_Request post_stop_type(::clean_msgs::srv::ManualCleanCtrl_Request::_post_stop_type_type arg)
  {
    msg_.post_stop_type = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::ManualCleanCtrl_Request msg_;
};

class Init_ManualCleanCtrl_Request_mode_id
{
public:
  explicit Init_ManualCleanCtrl_Request_mode_id(::clean_msgs::srv::ManualCleanCtrl_Request & msg)
  : msg_(msg)
  {}
  Init_ManualCleanCtrl_Request_post_stop_type mode_id(::clean_msgs::srv::ManualCleanCtrl_Request::_mode_id_type arg)
  {
    msg_.mode_id = std::move(arg);
    return Init_ManualCleanCtrl_Request_post_stop_type(msg_);
  }

private:
  ::clean_msgs::srv::ManualCleanCtrl_Request msg_;
};

class Init_ManualCleanCtrl_Request_exec_id
{
public:
  explicit Init_ManualCleanCtrl_Request_exec_id(::clean_msgs::srv::ManualCleanCtrl_Request & msg)
  : msg_(msg)
  {}
  Init_ManualCleanCtrl_Request_mode_id exec_id(::clean_msgs::srv::ManualCleanCtrl_Request::_exec_id_type arg)
  {
    msg_.exec_id = std::move(arg);
    return Init_ManualCleanCtrl_Request_mode_id(msg_);
  }

private:
  ::clean_msgs::srv::ManualCleanCtrl_Request msg_;
};

class Init_ManualCleanCtrl_Request_cmd
{
public:
  Init_ManualCleanCtrl_Request_cmd()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ManualCleanCtrl_Request_exec_id cmd(::clean_msgs::srv::ManualCleanCtrl_Request::_cmd_type arg)
  {
    msg_.cmd = std::move(arg);
    return Init_ManualCleanCtrl_Request_exec_id(msg_);
  }

private:
  ::clean_msgs::srv::ManualCleanCtrl_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::ManualCleanCtrl_Request>()
{
  return clean_msgs::srv::builder::Init_ManualCleanCtrl_Request_cmd();
}

}  // namespace clean_msgs


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_ManualCleanCtrl_Response_exec_id
{
public:
  explicit Init_ManualCleanCtrl_Response_exec_id(::clean_msgs::srv::ManualCleanCtrl_Response & msg)
  : msg_(msg)
  {}
  ::clean_msgs::srv::ManualCleanCtrl_Response exec_id(::clean_msgs::srv::ManualCleanCtrl_Response::_exec_id_type arg)
  {
    msg_.exec_id = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::ManualCleanCtrl_Response msg_;
};

class Init_ManualCleanCtrl_Response_result
{
public:
  Init_ManualCleanCtrl_Response_result()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ManualCleanCtrl_Response_exec_id result(::clean_msgs::srv::ManualCleanCtrl_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return Init_ManualCleanCtrl_Response_exec_id(msg_);
  }

private:
  ::clean_msgs::srv::ManualCleanCtrl_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::ManualCleanCtrl_Response>()
{
  return clean_msgs::srv::builder::Init_ManualCleanCtrl_Response_result();
}

}  // namespace clean_msgs

#endif  // CLEAN_MSGS__SRV__DETAIL__MANUAL_CLEAN_CTRL__BUILDER_HPP_
