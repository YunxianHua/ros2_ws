// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from clean_msgs:srv/MapPrepareTypeTransfer.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__MAP_PREPARE_TYPE_TRANSFER__BUILDER_HPP_
#define CLEAN_MSGS__SRV__DETAIL__MAP_PREPARE_TYPE_TRANSFER__BUILDER_HPP_

#include "clean_msgs/srv/detail/map_prepare_type_transfer__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_MapPrepareTypeTransfer_Request_map_id
{
public:
  explicit Init_MapPrepareTypeTransfer_Request_map_id(::clean_msgs::srv::MapPrepareTypeTransfer_Request & msg)
  : msg_(msg)
  {}
  ::clean_msgs::srv::MapPrepareTypeTransfer_Request map_id(::clean_msgs::srv::MapPrepareTypeTransfer_Request::_map_id_type arg)
  {
    msg_.map_id = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::MapPrepareTypeTransfer_Request msg_;
};

class Init_MapPrepareTypeTransfer_Request_prepare_mode
{
public:
  Init_MapPrepareTypeTransfer_Request_prepare_mode()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MapPrepareTypeTransfer_Request_map_id prepare_mode(::clean_msgs::srv::MapPrepareTypeTransfer_Request::_prepare_mode_type arg)
  {
    msg_.prepare_mode = std::move(arg);
    return Init_MapPrepareTypeTransfer_Request_map_id(msg_);
  }

private:
  ::clean_msgs::srv::MapPrepareTypeTransfer_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::MapPrepareTypeTransfer_Request>()
{
  return clean_msgs::srv::builder::Init_MapPrepareTypeTransfer_Request_prepare_mode();
}

}  // namespace clean_msgs


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_MapPrepareTypeTransfer_Response_is_dirty
{
public:
  explicit Init_MapPrepareTypeTransfer_Response_is_dirty(::clean_msgs::srv::MapPrepareTypeTransfer_Response & msg)
  : msg_(msg)
  {}
  ::clean_msgs::srv::MapPrepareTypeTransfer_Response is_dirty(::clean_msgs::srv::MapPrepareTypeTransfer_Response::_is_dirty_type arg)
  {
    msg_.is_dirty = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::MapPrepareTypeTransfer_Response msg_;
};

class Init_MapPrepareTypeTransfer_Response_map_ver
{
public:
  explicit Init_MapPrepareTypeTransfer_Response_map_ver(::clean_msgs::srv::MapPrepareTypeTransfer_Response & msg)
  : msg_(msg)
  {}
  Init_MapPrepareTypeTransfer_Response_is_dirty map_ver(::clean_msgs::srv::MapPrepareTypeTransfer_Response::_map_ver_type arg)
  {
    msg_.map_ver = std::move(arg);
    return Init_MapPrepareTypeTransfer_Response_is_dirty(msg_);
  }

private:
  ::clean_msgs::srv::MapPrepareTypeTransfer_Response msg_;
};

class Init_MapPrepareTypeTransfer_Response_result
{
public:
  Init_MapPrepareTypeTransfer_Response_result()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MapPrepareTypeTransfer_Response_map_ver result(::clean_msgs::srv::MapPrepareTypeTransfer_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return Init_MapPrepareTypeTransfer_Response_map_ver(msg_);
  }

private:
  ::clean_msgs::srv::MapPrepareTypeTransfer_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::MapPrepareTypeTransfer_Response>()
{
  return clean_msgs::srv::builder::Init_MapPrepareTypeTransfer_Response_result();
}

}  // namespace clean_msgs

#endif  // CLEAN_MSGS__SRV__DETAIL__MAP_PREPARE_TYPE_TRANSFER__BUILDER_HPP_
