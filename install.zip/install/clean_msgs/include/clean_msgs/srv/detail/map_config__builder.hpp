// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from clean_msgs:srv/MapConfig.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__MAP_CONFIG__BUILDER_HPP_
#define CLEAN_MSGS__SRV__DETAIL__MAP_CONFIG__BUILDER_HPP_

#include "clean_msgs/srv/detail/map_config__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_MapConfig_Request_data_info
{
public:
  explicit Init_MapConfig_Request_data_info(::clean_msgs::srv::MapConfig_Request & msg)
  : msg_(msg)
  {}
  ::clean_msgs::srv::MapConfig_Request data_info(::clean_msgs::srv::MapConfig_Request::_data_info_type arg)
  {
    msg_.data_info = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::MapConfig_Request msg_;
};

class Init_MapConfig_Request_map_info
{
public:
  explicit Init_MapConfig_Request_map_info(::clean_msgs::srv::MapConfig_Request & msg)
  : msg_(msg)
  {}
  Init_MapConfig_Request_data_info map_info(::clean_msgs::srv::MapConfig_Request::_map_info_type arg)
  {
    msg_.map_info = std::move(arg);
    return Init_MapConfig_Request_data_info(msg_);
  }

private:
  ::clean_msgs::srv::MapConfig_Request msg_;
};

class Init_MapConfig_Request_exec_id
{
public:
  explicit Init_MapConfig_Request_exec_id(::clean_msgs::srv::MapConfig_Request & msg)
  : msg_(msg)
  {}
  Init_MapConfig_Request_map_info exec_id(::clean_msgs::srv::MapConfig_Request::_exec_id_type arg)
  {
    msg_.exec_id = std::move(arg);
    return Init_MapConfig_Request_map_info(msg_);
  }

private:
  ::clean_msgs::srv::MapConfig_Request msg_;
};

class Init_MapConfig_Request_cmd
{
public:
  Init_MapConfig_Request_cmd()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MapConfig_Request_exec_id cmd(::clean_msgs::srv::MapConfig_Request::_cmd_type arg)
  {
    msg_.cmd = std::move(arg);
    return Init_MapConfig_Request_exec_id(msg_);
  }

private:
  ::clean_msgs::srv::MapConfig_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::MapConfig_Request>()
{
  return clean_msgs::srv::builder::Init_MapConfig_Request_cmd();
}

}  // namespace clean_msgs


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_MapConfig_Response_map_id
{
public:
  explicit Init_MapConfig_Response_map_id(::clean_msgs::srv::MapConfig_Response & msg)
  : msg_(msg)
  {}
  ::clean_msgs::srv::MapConfig_Response map_id(::clean_msgs::srv::MapConfig_Response::_map_id_type arg)
  {
    msg_.map_id = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::MapConfig_Response msg_;
};

class Init_MapConfig_Response_result
{
public:
  Init_MapConfig_Response_result()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MapConfig_Response_map_id result(::clean_msgs::srv::MapConfig_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return Init_MapConfig_Response_map_id(msg_);
  }

private:
  ::clean_msgs::srv::MapConfig_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::MapConfig_Response>()
{
  return clean_msgs::srv::builder::Init_MapConfig_Response_result();
}

}  // namespace clean_msgs

#endif  // CLEAN_MSGS__SRV__DETAIL__MAP_CONFIG__BUILDER_HPP_
