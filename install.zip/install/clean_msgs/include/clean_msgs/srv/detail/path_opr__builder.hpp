// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from clean_msgs:srv/PathOpr.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__PATH_OPR__BUILDER_HPP_
#define CLEAN_MSGS__SRV__DETAIL__PATH_OPR__BUILDER_HPP_

#include "clean_msgs/srv/detail/path_opr__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_PathOpr_Request_zones
{
public:
  explicit Init_PathOpr_Request_zones(::clean_msgs::srv::PathOpr_Request & msg)
  : msg_(msg)
  {}
  ::clean_msgs::srv::PathOpr_Request zones(::clean_msgs::srv::PathOpr_Request::_zones_type arg)
  {
    msg_.zones = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::PathOpr_Request msg_;
};

class Init_PathOpr_Request_polylines
{
public:
  explicit Init_PathOpr_Request_polylines(::clean_msgs::srv::PathOpr_Request & msg)
  : msg_(msg)
  {}
  Init_PathOpr_Request_zones polylines(::clean_msgs::srv::PathOpr_Request::_polylines_type arg)
  {
    msg_.polylines = std::move(arg);
    return Init_PathOpr_Request_zones(msg_);
  }

private:
  ::clean_msgs::srv::PathOpr_Request msg_;
};

class Init_PathOpr_Request_path_dir
{
public:
  explicit Init_PathOpr_Request_path_dir(::clean_msgs::srv::PathOpr_Request & msg)
  : msg_(msg)
  {}
  Init_PathOpr_Request_polylines path_dir(::clean_msgs::srv::PathOpr_Request::_path_dir_type arg)
  {
    msg_.path_dir = std::move(arg);
    return Init_PathOpr_Request_polylines(msg_);
  }

private:
  ::clean_msgs::srv::PathOpr_Request msg_;
};

class Init_PathOpr_Request_map_id
{
public:
  explicit Init_PathOpr_Request_map_id(::clean_msgs::srv::PathOpr_Request & msg)
  : msg_(msg)
  {}
  Init_PathOpr_Request_path_dir map_id(::clean_msgs::srv::PathOpr_Request::_map_id_type arg)
  {
    msg_.map_id = std::move(arg);
    return Init_PathOpr_Request_path_dir(msg_);
  }

private:
  ::clean_msgs::srv::PathOpr_Request msg_;
};

class Init_PathOpr_Request_cmd
{
public:
  Init_PathOpr_Request_cmd()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_PathOpr_Request_map_id cmd(::clean_msgs::srv::PathOpr_Request::_cmd_type arg)
  {
    msg_.cmd = std::move(arg);
    return Init_PathOpr_Request_map_id(msg_);
  }

private:
  ::clean_msgs::srv::PathOpr_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::PathOpr_Request>()
{
  return clean_msgs::srv::builder::Init_PathOpr_Request_cmd();
}

}  // namespace clean_msgs


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_PathOpr_Response_new_zones
{
public:
  explicit Init_PathOpr_Response_new_zones(::clean_msgs::srv::PathOpr_Response & msg)
  : msg_(msg)
  {}
  ::clean_msgs::srv::PathOpr_Response new_zones(::clean_msgs::srv::PathOpr_Response::_new_zones_type arg)
  {
    msg_.new_zones = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::PathOpr_Response msg_;
};

class Init_PathOpr_Response_delete_path_ids
{
public:
  explicit Init_PathOpr_Response_delete_path_ids(::clean_msgs::srv::PathOpr_Response & msg)
  : msg_(msg)
  {}
  Init_PathOpr_Response_new_zones delete_path_ids(::clean_msgs::srv::PathOpr_Response::_delete_path_ids_type arg)
  {
    msg_.delete_path_ids = std::move(arg);
    return Init_PathOpr_Response_new_zones(msg_);
  }

private:
  ::clean_msgs::srv::PathOpr_Response msg_;
};

class Init_PathOpr_Response_result
{
public:
  Init_PathOpr_Response_result()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_PathOpr_Response_delete_path_ids result(::clean_msgs::srv::PathOpr_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return Init_PathOpr_Response_delete_path_ids(msg_);
  }

private:
  ::clean_msgs::srv::PathOpr_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::PathOpr_Response>()
{
  return clean_msgs::srv::builder::Init_PathOpr_Response_result();
}

}  // namespace clean_msgs

#endif  // CLEAN_MSGS__SRV__DETAIL__PATH_OPR__BUILDER_HPP_
