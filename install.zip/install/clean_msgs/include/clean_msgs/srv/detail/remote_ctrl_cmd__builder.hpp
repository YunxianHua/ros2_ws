// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from clean_msgs:srv/RemoteCtrlCmd.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__REMOTE_CTRL_CMD__BUILDER_HPP_
#define CLEAN_MSGS__SRV__DETAIL__REMOTE_CTRL_CMD__BUILDER_HPP_

#include "clean_msgs/srv/detail/remote_ctrl_cmd__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_RemoteCtrlCmd_Request_angle
{
public:
  explicit Init_RemoteCtrlCmd_Request_angle(::clean_msgs::srv::RemoteCtrlCmd_Request & msg)
  : msg_(msg)
  {}
  ::clean_msgs::srv::RemoteCtrlCmd_Request angle(::clean_msgs::srv::RemoteCtrlCmd_Request::_angle_type arg)
  {
    msg_.angle = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::RemoteCtrlCmd_Request msg_;
};

class Init_RemoteCtrlCmd_Request_linear
{
public:
  explicit Init_RemoteCtrlCmd_Request_linear(::clean_msgs::srv::RemoteCtrlCmd_Request & msg)
  : msg_(msg)
  {}
  Init_RemoteCtrlCmd_Request_angle linear(::clean_msgs::srv::RemoteCtrlCmd_Request::_linear_type arg)
  {
    msg_.linear = std::move(arg);
    return Init_RemoteCtrlCmd_Request_angle(msg_);
  }

private:
  ::clean_msgs::srv::RemoteCtrlCmd_Request msg_;
};

class Init_RemoteCtrlCmd_Request_turning
{
public:
  explicit Init_RemoteCtrlCmd_Request_turning(::clean_msgs::srv::RemoteCtrlCmd_Request & msg)
  : msg_(msg)
  {}
  Init_RemoteCtrlCmd_Request_linear turning(::clean_msgs::srv::RemoteCtrlCmd_Request::_turning_type arg)
  {
    msg_.turning = std::move(arg);
    return Init_RemoteCtrlCmd_Request_linear(msg_);
  }

private:
  ::clean_msgs::srv::RemoteCtrlCmd_Request msg_;
};

class Init_RemoteCtrlCmd_Request_direction
{
public:
  explicit Init_RemoteCtrlCmd_Request_direction(::clean_msgs::srv::RemoteCtrlCmd_Request & msg)
  : msg_(msg)
  {}
  Init_RemoteCtrlCmd_Request_turning direction(::clean_msgs::srv::RemoteCtrlCmd_Request::_direction_type arg)
  {
    msg_.direction = std::move(arg);
    return Init_RemoteCtrlCmd_Request_turning(msg_);
  }

private:
  ::clean_msgs::srv::RemoteCtrlCmd_Request msg_;
};

class Init_RemoteCtrlCmd_Request_session_id
{
public:
  explicit Init_RemoteCtrlCmd_Request_session_id(::clean_msgs::srv::RemoteCtrlCmd_Request & msg)
  : msg_(msg)
  {}
  Init_RemoteCtrlCmd_Request_direction session_id(::clean_msgs::srv::RemoteCtrlCmd_Request::_session_id_type arg)
  {
    msg_.session_id = std::move(arg);
    return Init_RemoteCtrlCmd_Request_direction(msg_);
  }

private:
  ::clean_msgs::srv::RemoteCtrlCmd_Request msg_;
};

class Init_RemoteCtrlCmd_Request_time_stamp2
{
public:
  explicit Init_RemoteCtrlCmd_Request_time_stamp2(::clean_msgs::srv::RemoteCtrlCmd_Request & msg)
  : msg_(msg)
  {}
  Init_RemoteCtrlCmd_Request_session_id time_stamp2(::clean_msgs::srv::RemoteCtrlCmd_Request::_time_stamp2_type arg)
  {
    msg_.time_stamp2 = std::move(arg);
    return Init_RemoteCtrlCmd_Request_session_id(msg_);
  }

private:
  ::clean_msgs::srv::RemoteCtrlCmd_Request msg_;
};

class Init_RemoteCtrlCmd_Request_time_stamp1
{
public:
  explicit Init_RemoteCtrlCmd_Request_time_stamp1(::clean_msgs::srv::RemoteCtrlCmd_Request & msg)
  : msg_(msg)
  {}
  Init_RemoteCtrlCmd_Request_time_stamp2 time_stamp1(::clean_msgs::srv::RemoteCtrlCmd_Request::_time_stamp1_type arg)
  {
    msg_.time_stamp1 = std::move(arg);
    return Init_RemoteCtrlCmd_Request_time_stamp2(msg_);
  }

private:
  ::clean_msgs::srv::RemoteCtrlCmd_Request msg_;
};

class Init_RemoteCtrlCmd_Request_cmd_type
{
public:
  Init_RemoteCtrlCmd_Request_cmd_type()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RemoteCtrlCmd_Request_time_stamp1 cmd_type(::clean_msgs::srv::RemoteCtrlCmd_Request::_cmd_type_type arg)
  {
    msg_.cmd_type = std::move(arg);
    return Init_RemoteCtrlCmd_Request_time_stamp1(msg_);
  }

private:
  ::clean_msgs::srv::RemoteCtrlCmd_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::RemoteCtrlCmd_Request>()
{
  return clean_msgs::srv::builder::Init_RemoteCtrlCmd_Request_cmd_type();
}

}  // namespace clean_msgs


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_RemoteCtrlCmd_Response_session_id
{
public:
  explicit Init_RemoteCtrlCmd_Response_session_id(::clean_msgs::srv::RemoteCtrlCmd_Response & msg)
  : msg_(msg)
  {}
  ::clean_msgs::srv::RemoteCtrlCmd_Response session_id(::clean_msgs::srv::RemoteCtrlCmd_Response::_session_id_type arg)
  {
    msg_.session_id = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::RemoteCtrlCmd_Response msg_;
};

class Init_RemoteCtrlCmd_Response_time_stamp
{
public:
  explicit Init_RemoteCtrlCmd_Response_time_stamp(::clean_msgs::srv::RemoteCtrlCmd_Response & msg)
  : msg_(msg)
  {}
  Init_RemoteCtrlCmd_Response_session_id time_stamp(::clean_msgs::srv::RemoteCtrlCmd_Response::_time_stamp_type arg)
  {
    msg_.time_stamp = std::move(arg);
    return Init_RemoteCtrlCmd_Response_session_id(msg_);
  }

private:
  ::clean_msgs::srv::RemoteCtrlCmd_Response msg_;
};

class Init_RemoteCtrlCmd_Response_result
{
public:
  Init_RemoteCtrlCmd_Response_result()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RemoteCtrlCmd_Response_time_stamp result(::clean_msgs::srv::RemoteCtrlCmd_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return Init_RemoteCtrlCmd_Response_time_stamp(msg_);
  }

private:
  ::clean_msgs::srv::RemoteCtrlCmd_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::RemoteCtrlCmd_Response>()
{
  return clean_msgs::srv::builder::Init_RemoteCtrlCmd_Response_result();
}

}  // namespace clean_msgs

#endif  // CLEAN_MSGS__SRV__DETAIL__REMOTE_CTRL_CMD__BUILDER_HPP_
