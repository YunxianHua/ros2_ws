// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from clean_msgs:srv/MapPrepareTypeTransfer.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__MAP_PREPARE_TYPE_TRANSFER__TRAITS_HPP_
#define CLEAN_MSGS__SRV__DETAIL__MAP_PREPARE_TYPE_TRANSFER__TRAITS_HPP_

#include "clean_msgs/srv/detail/map_prepare_type_transfer__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<clean_msgs::srv::MapPrepareTypeTransfer_Request>()
{
  return "clean_msgs::srv::MapPrepareTypeTransfer_Request";
}

template<>
inline const char * name<clean_msgs::srv::MapPrepareTypeTransfer_Request>()
{
  return "clean_msgs/srv/MapPrepareTypeTransfer_Request";
}

template<>
struct has_fixed_size<clean_msgs::srv::MapPrepareTypeTransfer_Request>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<clean_msgs::srv::MapPrepareTypeTransfer_Request>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<clean_msgs::srv::MapPrepareTypeTransfer_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<clean_msgs::srv::MapPrepareTypeTransfer_Response>()
{
  return "clean_msgs::srv::MapPrepareTypeTransfer_Response";
}

template<>
inline const char * name<clean_msgs::srv::MapPrepareTypeTransfer_Response>()
{
  return "clean_msgs/srv/MapPrepareTypeTransfer_Response";
}

template<>
struct has_fixed_size<clean_msgs::srv::MapPrepareTypeTransfer_Response>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<clean_msgs::srv::MapPrepareTypeTransfer_Response>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<clean_msgs::srv::MapPrepareTypeTransfer_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<clean_msgs::srv::MapPrepareTypeTransfer>()
{
  return "clean_msgs::srv::MapPrepareTypeTransfer";
}

template<>
inline const char * name<clean_msgs::srv::MapPrepareTypeTransfer>()
{
  return "clean_msgs/srv/MapPrepareTypeTransfer";
}

template<>
struct has_fixed_size<clean_msgs::srv::MapPrepareTypeTransfer>
  : std::integral_constant<
    bool,
    has_fixed_size<clean_msgs::srv::MapPrepareTypeTransfer_Request>::value &&
    has_fixed_size<clean_msgs::srv::MapPrepareTypeTransfer_Response>::value
  >
{
};

template<>
struct has_bounded_size<clean_msgs::srv::MapPrepareTypeTransfer>
  : std::integral_constant<
    bool,
    has_bounded_size<clean_msgs::srv::MapPrepareTypeTransfer_Request>::value &&
    has_bounded_size<clean_msgs::srv::MapPrepareTypeTransfer_Response>::value
  >
{
};

template<>
struct is_service<clean_msgs::srv::MapPrepareTypeTransfer>
  : std::true_type
{
};

template<>
struct is_service_request<clean_msgs::srv::MapPrepareTypeTransfer_Request>
  : std::true_type
{
};

template<>
struct is_service_response<clean_msgs::srv::MapPrepareTypeTransfer_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // CLEAN_MSGS__SRV__DETAIL__MAP_PREPARE_TYPE_TRANSFER__TRAITS_HPP_
