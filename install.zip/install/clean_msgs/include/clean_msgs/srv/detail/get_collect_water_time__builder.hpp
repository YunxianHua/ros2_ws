// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from clean_msgs:srv/GetCollectWaterTime.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__GET_COLLECT_WATER_TIME__BUILDER_HPP_
#define CLEAN_MSGS__SRV__DETAIL__GET_COLLECT_WATER_TIME__BUILDER_HPP_

#include "clean_msgs/srv/detail/get_collect_water_time__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_GetCollectWaterTime_Request_phase_type
{
public:
  Init_GetCollectWaterTime_Request_phase_type()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::clean_msgs::srv::GetCollectWaterTime_Request phase_type(::clean_msgs::srv::GetCollectWaterTime_Request::_phase_type_type arg)
  {
    msg_.phase_type = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::GetCollectWaterTime_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::GetCollectWaterTime_Request>()
{
  return clean_msgs::srv::builder::Init_GetCollectWaterTime_Request_phase_type();
}

}  // namespace clean_msgs


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_GetCollectWaterTime_Response_time
{
public:
  explicit Init_GetCollectWaterTime_Response_time(::clean_msgs::srv::GetCollectWaterTime_Response & msg)
  : msg_(msg)
  {}
  ::clean_msgs::srv::GetCollectWaterTime_Response time(::clean_msgs::srv::GetCollectWaterTime_Response::_time_type arg)
  {
    msg_.time = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::GetCollectWaterTime_Response msg_;
};

class Init_GetCollectWaterTime_Response_result
{
public:
  Init_GetCollectWaterTime_Response_result()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_GetCollectWaterTime_Response_time result(::clean_msgs::srv::GetCollectWaterTime_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return Init_GetCollectWaterTime_Response_time(msg_);
  }

private:
  ::clean_msgs::srv::GetCollectWaterTime_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::GetCollectWaterTime_Response>()
{
  return clean_msgs::srv::builder::Init_GetCollectWaterTime_Response_result();
}

}  // namespace clean_msgs

#endif  // CLEAN_MSGS__SRV__DETAIL__GET_COLLECT_WATER_TIME__BUILDER_HPP_
