// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from clean_msgs:srv/MapConfig.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__MAP_CONFIG__STRUCT_H_
#define CLEAN_MSGS__SRV__DETAIL__MAP_CONFIG__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'MAP_START'.
enum
{
  clean_msgs__srv__MapConfig_Request__MAP_START = 1ul
};

/// Constant 'MAP_SAVE'.
enum
{
  clean_msgs__srv__MapConfig_Request__MAP_SAVE = 2ul
};

/// Constant 'MAP_UPDATE'.
enum
{
  clean_msgs__srv__MapConfig_Request__MAP_UPDATE = 3ul
};

/// Constant 'MAP_CANCEL'.
enum
{
  clean_msgs__srv__MapConfig_Request__MAP_CANCEL = 4ul
};

/// Constant 'MAP_DELETE'.
enum
{
  clean_msgs__srv__MapConfig_Request__MAP_DELETE = 5ul
};

/// Constant 'MAP_EXTEND'.
enum
{
  clean_msgs__srv__MapConfig_Request__MAP_EXTEND = 6ul
};

/// Constant 'MAP_LOOP'.
enum
{
  clean_msgs__srv__MapConfig_Request__MAP_LOOP = 7ul
};

// Include directives for member types
// Member 'exec_id'
#include "rosidl_runtime_c/string.h"
// Member 'map_info'
#include "clean_msgs/msg/detail/map_info__struct.h"
// Member 'data_info'
#include "clean_msgs/msg/detail/map_data_update_info__struct.h"

// Struct defined in srv/MapConfig in the package clean_msgs.
typedef struct clean_msgs__srv__MapConfig_Request
{
  uint32_t cmd;
  rosidl_runtime_c__String exec_id;
  clean_msgs__msg__MapInfo map_info;
  clean_msgs__msg__MapDataUpdateInfo__Sequence data_info;
} clean_msgs__srv__MapConfig_Request;

// Struct for a sequence of clean_msgs__srv__MapConfig_Request.
typedef struct clean_msgs__srv__MapConfig_Request__Sequence
{
  clean_msgs__srv__MapConfig_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} clean_msgs__srv__MapConfig_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'map_id'
// already included above
// #include "rosidl_runtime_c/string.h"

// Struct defined in srv/MapConfig in the package clean_msgs.
typedef struct clean_msgs__srv__MapConfig_Response
{
  uint32_t result;
  rosidl_runtime_c__String map_id;
} clean_msgs__srv__MapConfig_Response;

// Struct for a sequence of clean_msgs__srv__MapConfig_Response.
typedef struct clean_msgs__srv__MapConfig_Response__Sequence
{
  clean_msgs__srv__MapConfig_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} clean_msgs__srv__MapConfig_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CLEAN_MSGS__SRV__DETAIL__MAP_CONFIG__STRUCT_H_
