// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from clean_msgs:srv/TaskList.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__TASK_LIST__BUILDER_HPP_
#define CLEAN_MSGS__SRV__DETAIL__TASK_LIST__BUILDER_HPP_

#include "clean_msgs/srv/detail/task_list__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace clean_msgs
{

namespace srv
{


}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::TaskList_Request>()
{
  return ::clean_msgs::srv::TaskList_Request(rosidl_runtime_cpp::MessageInitialization::ZERO);
}

}  // namespace clean_msgs


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_TaskList_Response_task_ids
{
public:
  explicit Init_TaskList_Response_task_ids(::clean_msgs::srv::TaskList_Response & msg)
  : msg_(msg)
  {}
  ::clean_msgs::srv::TaskList_Response task_ids(::clean_msgs::srv::TaskList_Response::_task_ids_type arg)
  {
    msg_.task_ids = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::TaskList_Response msg_;
};

class Init_TaskList_Response_result
{
public:
  Init_TaskList_Response_result()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_TaskList_Response_task_ids result(::clean_msgs::srv::TaskList_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return Init_TaskList_Response_task_ids(msg_);
  }

private:
  ::clean_msgs::srv::TaskList_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::TaskList_Response>()
{
  return clean_msgs::srv::builder::Init_TaskList_Response_result();
}

}  // namespace clean_msgs

#endif  // CLEAN_MSGS__SRV__DETAIL__TASK_LIST__BUILDER_HPP_
