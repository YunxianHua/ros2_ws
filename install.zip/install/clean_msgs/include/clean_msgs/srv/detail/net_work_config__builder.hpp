// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from clean_msgs:srv/NetWorkConfig.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__NET_WORK_CONFIG__BUILDER_HPP_
#define CLEAN_MSGS__SRV__DETAIL__NET_WORK_CONFIG__BUILDER_HPP_

#include "clean_msgs/srv/detail/net_work_config__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_NetWorkConfig_Request_wireless_passwd
{
public:
  explicit Init_NetWorkConfig_Request_wireless_passwd(::clean_msgs::srv::NetWorkConfig_Request & msg)
  : msg_(msg)
  {}
  ::clean_msgs::srv::NetWorkConfig_Request wireless_passwd(::clean_msgs::srv::NetWorkConfig_Request::_wireless_passwd_type arg)
  {
    msg_.wireless_passwd = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::NetWorkConfig_Request msg_;
};

class Init_NetWorkConfig_Request_wireless_name
{
public:
  explicit Init_NetWorkConfig_Request_wireless_name(::clean_msgs::srv::NetWorkConfig_Request & msg)
  : msg_(msg)
  {}
  Init_NetWorkConfig_Request_wireless_passwd wireless_name(::clean_msgs::srv::NetWorkConfig_Request::_wireless_name_type arg)
  {
    msg_.wireless_name = std::move(arg);
    return Init_NetWorkConfig_Request_wireless_passwd(msg_);
  }

private:
  ::clean_msgs::srv::NetWorkConfig_Request msg_;
};

class Init_NetWorkConfig_Request_type
{
public:
  explicit Init_NetWorkConfig_Request_type(::clean_msgs::srv::NetWorkConfig_Request & msg)
  : msg_(msg)
  {}
  Init_NetWorkConfig_Request_wireless_name type(::clean_msgs::srv::NetWorkConfig_Request::_type_type arg)
  {
    msg_.type = std::move(arg);
    return Init_NetWorkConfig_Request_wireless_name(msg_);
  }

private:
  ::clean_msgs::srv::NetWorkConfig_Request msg_;
};

class Init_NetWorkConfig_Request_cmd
{
public:
  Init_NetWorkConfig_Request_cmd()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_NetWorkConfig_Request_type cmd(::clean_msgs::srv::NetWorkConfig_Request::_cmd_type arg)
  {
    msg_.cmd = std::move(arg);
    return Init_NetWorkConfig_Request_type(msg_);
  }

private:
  ::clean_msgs::srv::NetWorkConfig_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::NetWorkConfig_Request>()
{
  return clean_msgs::srv::builder::Init_NetWorkConfig_Request_cmd();
}

}  // namespace clean_msgs


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_NetWorkConfig_Response_hostspot_passwd
{
public:
  explicit Init_NetWorkConfig_Response_hostspot_passwd(::clean_msgs::srv::NetWorkConfig_Response & msg)
  : msg_(msg)
  {}
  ::clean_msgs::srv::NetWorkConfig_Response hostspot_passwd(::clean_msgs::srv::NetWorkConfig_Response::_hostspot_passwd_type arg)
  {
    msg_.hostspot_passwd = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::NetWorkConfig_Response msg_;
};

class Init_NetWorkConfig_Response_hotspot_name
{
public:
  explicit Init_NetWorkConfig_Response_hotspot_name(::clean_msgs::srv::NetWorkConfig_Response & msg)
  : msg_(msg)
  {}
  Init_NetWorkConfig_Response_hostspot_passwd hotspot_name(::clean_msgs::srv::NetWorkConfig_Response::_hotspot_name_type arg)
  {
    msg_.hotspot_name = std::move(arg);
    return Init_NetWorkConfig_Response_hostspot_passwd(msg_);
  }

private:
  ::clean_msgs::srv::NetWorkConfig_Response msg_;
};

class Init_NetWorkConfig_Response_hotspot_enable
{
public:
  explicit Init_NetWorkConfig_Response_hotspot_enable(::clean_msgs::srv::NetWorkConfig_Response & msg)
  : msg_(msg)
  {}
  Init_NetWorkConfig_Response_hotspot_name hotspot_enable(::clean_msgs::srv::NetWorkConfig_Response::_hotspot_enable_type arg)
  {
    msg_.hotspot_enable = std::move(arg);
    return Init_NetWorkConfig_Response_hotspot_name(msg_);
  }

private:
  ::clean_msgs::srv::NetWorkConfig_Response msg_;
};

class Init_NetWorkConfig_Response_wireless_infos
{
public:
  explicit Init_NetWorkConfig_Response_wireless_infos(::clean_msgs::srv::NetWorkConfig_Response & msg)
  : msg_(msg)
  {}
  Init_NetWorkConfig_Response_hotspot_enable wireless_infos(::clean_msgs::srv::NetWorkConfig_Response::_wireless_infos_type arg)
  {
    msg_.wireless_infos = std::move(arg);
    return Init_NetWorkConfig_Response_hotspot_enable(msg_);
  }

private:
  ::clean_msgs::srv::NetWorkConfig_Response msg_;
};

class Init_NetWorkConfig_Response_wireless_net_enable
{
public:
  explicit Init_NetWorkConfig_Response_wireless_net_enable(::clean_msgs::srv::NetWorkConfig_Response & msg)
  : msg_(msg)
  {}
  Init_NetWorkConfig_Response_wireless_infos wireless_net_enable(::clean_msgs::srv::NetWorkConfig_Response::_wireless_net_enable_type arg)
  {
    msg_.wireless_net_enable = std::move(arg);
    return Init_NetWorkConfig_Response_wireless_infos(msg_);
  }

private:
  ::clean_msgs::srv::NetWorkConfig_Response msg_;
};

class Init_NetWorkConfig_Response_cellular_signal
{
public:
  explicit Init_NetWorkConfig_Response_cellular_signal(::clean_msgs::srv::NetWorkConfig_Response & msg)
  : msg_(msg)
  {}
  Init_NetWorkConfig_Response_wireless_net_enable cellular_signal(::clean_msgs::srv::NetWorkConfig_Response::_cellular_signal_type arg)
  {
    msg_.cellular_signal = std::move(arg);
    return Init_NetWorkConfig_Response_wireless_net_enable(msg_);
  }

private:
  ::clean_msgs::srv::NetWorkConfig_Response msg_;
};

class Init_NetWorkConfig_Response_cellular_standard
{
public:
  explicit Init_NetWorkConfig_Response_cellular_standard(::clean_msgs::srv::NetWorkConfig_Response & msg)
  : msg_(msg)
  {}
  Init_NetWorkConfig_Response_cellular_signal cellular_standard(::clean_msgs::srv::NetWorkConfig_Response::_cellular_standard_type arg)
  {
    msg_.cellular_standard = std::move(arg);
    return Init_NetWorkConfig_Response_cellular_signal(msg_);
  }

private:
  ::clean_msgs::srv::NetWorkConfig_Response msg_;
};

class Init_NetWorkConfig_Response_cellular_provider
{
public:
  explicit Init_NetWorkConfig_Response_cellular_provider(::clean_msgs::srv::NetWorkConfig_Response & msg)
  : msg_(msg)
  {}
  Init_NetWorkConfig_Response_cellular_standard cellular_provider(::clean_msgs::srv::NetWorkConfig_Response::_cellular_provider_type arg)
  {
    msg_.cellular_provider = std::move(arg);
    return Init_NetWorkConfig_Response_cellular_standard(msg_);
  }

private:
  ::clean_msgs::srv::NetWorkConfig_Response msg_;
};

class Init_NetWorkConfig_Response_cellular_net_enable
{
public:
  explicit Init_NetWorkConfig_Response_cellular_net_enable(::clean_msgs::srv::NetWorkConfig_Response & msg)
  : msg_(msg)
  {}
  Init_NetWorkConfig_Response_cellular_provider cellular_net_enable(::clean_msgs::srv::NetWorkConfig_Response::_cellular_net_enable_type arg)
  {
    msg_.cellular_net_enable = std::move(arg);
    return Init_NetWorkConfig_Response_cellular_provider(msg_);
  }

private:
  ::clean_msgs::srv::NetWorkConfig_Response msg_;
};

class Init_NetWorkConfig_Response_result
{
public:
  Init_NetWorkConfig_Response_result()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_NetWorkConfig_Response_cellular_net_enable result(::clean_msgs::srv::NetWorkConfig_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return Init_NetWorkConfig_Response_cellular_net_enable(msg_);
  }

private:
  ::clean_msgs::srv::NetWorkConfig_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::NetWorkConfig_Response>()
{
  return clean_msgs::srv::builder::Init_NetWorkConfig_Response_result();
}

}  // namespace clean_msgs

#endif  // CLEAN_MSGS__SRV__DETAIL__NET_WORK_CONFIG__BUILDER_HPP_
