// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from clean_msgs:srv/MapPrepareSync.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__MAP_PREPARE_SYNC__STRUCT_H_
#define CLEAN_MSGS__SRV__DETAIL__MAP_PREPARE_SYNC__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'MAP_SYNC_TYPE_UNKNOWN'.
enum
{
  clean_msgs__srv__MapPrepareSync_Request__MAP_SYNC_TYPE_UNKNOWN = 0ul
};

/// Constant 'MAP_SYNC_TYPE_UPLOAD'.
enum
{
  clean_msgs__srv__MapPrepareSync_Request__MAP_SYNC_TYPE_UPLOAD = 1ul
};

/// Constant 'MAP_SYNC_TYPE_DOWNLOAD'.
enum
{
  clean_msgs__srv__MapPrepareSync_Request__MAP_SYNC_TYPE_DOWNLOAD = 2ul
};

/// Constant 'MAP_TYPE_UNKNOWN'.
enum
{
  clean_msgs__srv__MapPrepareSync_Request__MAP_TYPE_UNKNOWN = 0ul
};

/// Constant 'MAP_TYPE_PRIVATE'.
enum
{
  clean_msgs__srv__MapPrepareSync_Request__MAP_TYPE_PRIVATE = 1ul
};

/// Constant 'MAP_TYPE_PROJECT'.
enum
{
  clean_msgs__srv__MapPrepareSync_Request__MAP_TYPE_PROJECT = 2ul
};

// Include directives for member types
// Member 'map_id'
#include "rosidl_runtime_c/string.h"

// Struct defined in srv/MapPrepareSync in the package clean_msgs.
typedef struct clean_msgs__srv__MapPrepareSync_Request
{
  uint32_t map_sync_type;
  rosidl_runtime_c__String map_id;
  uint32_t map_type;
} clean_msgs__srv__MapPrepareSync_Request;

// Struct for a sequence of clean_msgs__srv__MapPrepareSync_Request.
typedef struct clean_msgs__srv__MapPrepareSync_Request__Sequence
{
  clean_msgs__srv__MapPrepareSync_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} clean_msgs__srv__MapPrepareSync_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'pb_path'
// Member 'map_id'
// already included above
// #include "rosidl_runtime_c/string.h"

// Struct defined in srv/MapPrepareSync in the package clean_msgs.
typedef struct clean_msgs__srv__MapPrepareSync_Response
{
  uint32_t result;
  rosidl_runtime_c__String pb_path;
  rosidl_runtime_c__String map_id;
  uint32_t map_ver;
  bool is_dirty;
} clean_msgs__srv__MapPrepareSync_Response;

// Struct for a sequence of clean_msgs__srv__MapPrepareSync_Response.
typedef struct clean_msgs__srv__MapPrepareSync_Response__Sequence
{
  clean_msgs__srv__MapPrepareSync_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} clean_msgs__srv__MapPrepareSync_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CLEAN_MSGS__SRV__DETAIL__MAP_PREPARE_SYNC__STRUCT_H_
