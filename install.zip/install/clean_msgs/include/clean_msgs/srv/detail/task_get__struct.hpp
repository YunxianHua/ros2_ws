// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from clean_msgs:srv/TaskGet.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__TASK_GET__STRUCT_HPP_
#define CLEAN_MSGS__SRV__DETAIL__TASK_GET__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__clean_msgs__srv__TaskGet_Request __attribute__((deprecated))
#else
# define DEPRECATED__clean_msgs__srv__TaskGet_Request __declspec(deprecated)
#endif

namespace clean_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct TaskGet_Request_
{
  using Type = TaskGet_Request_<ContainerAllocator>;

  explicit TaskGet_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->type = 0;
      this->task_id = "";
    }
  }

  explicit TaskGet_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : task_id(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->type = 0;
      this->task_id = "";
    }
  }

  // field types and members
  using _type_type =
    uint8_t;
  _type_type type;
  using _task_id_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _task_id_type task_id;

  // setters for named parameter idiom
  Type & set__type(
    const uint8_t & _arg)
  {
    this->type = _arg;
    return *this;
  }
  Type & set__task_id(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->task_id = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint8_t TYPE_COMPO_TASK =
    1u;
  static constexpr uint8_t TYPE_BC_TASK =
    2u;

  // pointer types
  using RawPtr =
    clean_msgs::srv::TaskGet_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const clean_msgs::srv::TaskGet_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<clean_msgs::srv::TaskGet_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<clean_msgs::srv::TaskGet_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::TaskGet_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::TaskGet_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::TaskGet_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::TaskGet_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<clean_msgs::srv::TaskGet_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<clean_msgs::srv::TaskGet_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__clean_msgs__srv__TaskGet_Request
    std::shared_ptr<clean_msgs::srv::TaskGet_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__clean_msgs__srv__TaskGet_Request
    std::shared_ptr<clean_msgs::srv::TaskGet_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const TaskGet_Request_ & other) const
  {
    if (this->type != other.type) {
      return false;
    }
    if (this->task_id != other.task_id) {
      return false;
    }
    return true;
  }
  bool operator!=(const TaskGet_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct TaskGet_Request_

// alias to use template instance with default allocator
using TaskGet_Request =
  clean_msgs::srv::TaskGet_Request_<std::allocator<void>>;

// constant definitions
template<typename ContainerAllocator>
constexpr uint8_t TaskGet_Request_<ContainerAllocator>::TYPE_COMPO_TASK;
template<typename ContainerAllocator>
constexpr uint8_t TaskGet_Request_<ContainerAllocator>::TYPE_BC_TASK;

}  // namespace srv

}  // namespace clean_msgs


// Include directives for member types
// Member 'subtasks'
#include "clean_msgs/msg/detail/sub_task_info__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__clean_msgs__srv__TaskGet_Response __attribute__((deprecated))
#else
# define DEPRECATED__clean_msgs__srv__TaskGet_Response __declspec(deprecated)
#endif

namespace clean_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct TaskGet_Response_
{
  using Type = TaskGet_Response_<ContainerAllocator>;

  explicit TaskGet_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->result = 0ul;
      this->id = "";
      this->name = "";
      this->task_cleaning_mode_id = "";
      this->task_cleaning_mode_name = "";
      this->all_loop_count = 0ul;
      this->cur_loop_count = 0ul;
      this->task_start_time = "";
      this->task_suspend_time = "";
    }
  }

  explicit TaskGet_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : id(_alloc),
    name(_alloc),
    task_cleaning_mode_id(_alloc),
    task_cleaning_mode_name(_alloc),
    task_start_time(_alloc),
    task_suspend_time(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->result = 0ul;
      this->id = "";
      this->name = "";
      this->task_cleaning_mode_id = "";
      this->task_cleaning_mode_name = "";
      this->all_loop_count = 0ul;
      this->cur_loop_count = 0ul;
      this->task_start_time = "";
      this->task_suspend_time = "";
    }
  }

  // field types and members
  using _result_type =
    uint32_t;
  _result_type result;
  using _id_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _id_type id;
  using _name_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _name_type name;
  using _subtasks_type =
    std::vector<clean_msgs::msg::SubTaskInfo_<ContainerAllocator>, typename ContainerAllocator::template rebind<clean_msgs::msg::SubTaskInfo_<ContainerAllocator>>::other>;
  _subtasks_type subtasks;
  using _task_cleaning_mode_id_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _task_cleaning_mode_id_type task_cleaning_mode_id;
  using _task_cleaning_mode_name_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _task_cleaning_mode_name_type task_cleaning_mode_name;
  using _all_loop_count_type =
    uint32_t;
  _all_loop_count_type all_loop_count;
  using _cur_loop_count_type =
    uint32_t;
  _cur_loop_count_type cur_loop_count;
  using _task_start_time_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _task_start_time_type task_start_time;
  using _task_suspend_time_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _task_suspend_time_type task_suspend_time;

  // setters for named parameter idiom
  Type & set__result(
    const uint32_t & _arg)
  {
    this->result = _arg;
    return *this;
  }
  Type & set__id(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->id = _arg;
    return *this;
  }
  Type & set__name(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->name = _arg;
    return *this;
  }
  Type & set__subtasks(
    const std::vector<clean_msgs::msg::SubTaskInfo_<ContainerAllocator>, typename ContainerAllocator::template rebind<clean_msgs::msg::SubTaskInfo_<ContainerAllocator>>::other> & _arg)
  {
    this->subtasks = _arg;
    return *this;
  }
  Type & set__task_cleaning_mode_id(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->task_cleaning_mode_id = _arg;
    return *this;
  }
  Type & set__task_cleaning_mode_name(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->task_cleaning_mode_name = _arg;
    return *this;
  }
  Type & set__all_loop_count(
    const uint32_t & _arg)
  {
    this->all_loop_count = _arg;
    return *this;
  }
  Type & set__cur_loop_count(
    const uint32_t & _arg)
  {
    this->cur_loop_count = _arg;
    return *this;
  }
  Type & set__task_start_time(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->task_start_time = _arg;
    return *this;
  }
  Type & set__task_suspend_time(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->task_suspend_time = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    clean_msgs::srv::TaskGet_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const clean_msgs::srv::TaskGet_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<clean_msgs::srv::TaskGet_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<clean_msgs::srv::TaskGet_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::TaskGet_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::TaskGet_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::TaskGet_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::TaskGet_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<clean_msgs::srv::TaskGet_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<clean_msgs::srv::TaskGet_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__clean_msgs__srv__TaskGet_Response
    std::shared_ptr<clean_msgs::srv::TaskGet_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__clean_msgs__srv__TaskGet_Response
    std::shared_ptr<clean_msgs::srv::TaskGet_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const TaskGet_Response_ & other) const
  {
    if (this->result != other.result) {
      return false;
    }
    if (this->id != other.id) {
      return false;
    }
    if (this->name != other.name) {
      return false;
    }
    if (this->subtasks != other.subtasks) {
      return false;
    }
    if (this->task_cleaning_mode_id != other.task_cleaning_mode_id) {
      return false;
    }
    if (this->task_cleaning_mode_name != other.task_cleaning_mode_name) {
      return false;
    }
    if (this->all_loop_count != other.all_loop_count) {
      return false;
    }
    if (this->cur_loop_count != other.cur_loop_count) {
      return false;
    }
    if (this->task_start_time != other.task_start_time) {
      return false;
    }
    if (this->task_suspend_time != other.task_suspend_time) {
      return false;
    }
    return true;
  }
  bool operator!=(const TaskGet_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct TaskGet_Response_

// alias to use template instance with default allocator
using TaskGet_Response =
  clean_msgs::srv::TaskGet_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace clean_msgs

namespace clean_msgs
{

namespace srv
{

struct TaskGet
{
  using Request = clean_msgs::srv::TaskGet_Request;
  using Response = clean_msgs::srv::TaskGet_Response;
};

}  // namespace srv

}  // namespace clean_msgs

#endif  // CLEAN_MSGS__SRV__DETAIL__TASK_GET__STRUCT_HPP_
