// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from clean_msgs:srv/GetAgiBotVersion.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__GET_AGI_BOT_VERSION__STRUCT_H_
#define CLEAN_MSGS__SRV__DETAIL__GET_AGI_BOT_VERSION__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'GET_AGIBOT_VERSION'.
enum
{
  clean_msgs__srv__GetAgiBotVersion_Request__GET_AGIBOT_VERSION = 1ul
};

// Struct defined in srv/GetAgiBotVersion in the package clean_msgs.
typedef struct clean_msgs__srv__GetAgiBotVersion_Request
{
  uint32_t cmd;
} clean_msgs__srv__GetAgiBotVersion_Request;

// Struct for a sequence of clean_msgs__srv__GetAgiBotVersion_Request.
typedef struct clean_msgs__srv__GetAgiBotVersion_Request__Sequence
{
  clean_msgs__srv__GetAgiBotVersion_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} clean_msgs__srv__GetAgiBotVersion_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'product_version'
// Member 'soft_version'
// Member 'ip_address'
#include "rosidl_runtime_c/string.h"

// Struct defined in srv/GetAgiBotVersion in the package clean_msgs.
typedef struct clean_msgs__srv__GetAgiBotVersion_Response
{
  uint32_t result;
  rosidl_runtime_c__String product_version;
  rosidl_runtime_c__String soft_version;
  rosidl_runtime_c__String ip_address;
} clean_msgs__srv__GetAgiBotVersion_Response;

// Struct for a sequence of clean_msgs__srv__GetAgiBotVersion_Response.
typedef struct clean_msgs__srv__GetAgiBotVersion_Response__Sequence
{
  clean_msgs__srv__GetAgiBotVersion_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} clean_msgs__srv__GetAgiBotVersion_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CLEAN_MSGS__SRV__DETAIL__GET_AGI_BOT_VERSION__STRUCT_H_
