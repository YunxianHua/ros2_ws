// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from clean_msgs:srv/DeviceLevel.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "clean_msgs/srv/detail/device_level__rosidl_typesupport_introspection_c.h"
#include "clean_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "clean_msgs/srv/detail/device_level__functions.h"
#include "clean_msgs/srv/detail/device_level__struct.h"


// Include directives for member types
// Member `device_info`
#include "clean_msgs/msg/device_info.h"
// Member `device_info`
#include "clean_msgs/msg/detail/device_info__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void DeviceLevel_Request__rosidl_typesupport_introspection_c__DeviceLevel_Request_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  clean_msgs__srv__DeviceLevel_Request__init(message_memory);
}

void DeviceLevel_Request__rosidl_typesupport_introspection_c__DeviceLevel_Request_fini_function(void * message_memory)
{
  clean_msgs__srv__DeviceLevel_Request__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember DeviceLevel_Request__rosidl_typesupport_introspection_c__DeviceLevel_Request_message_member_array[2] = {
  {
    "cmd",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(clean_msgs__srv__DeviceLevel_Request, cmd),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "device_info",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(clean_msgs__srv__DeviceLevel_Request, device_info),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers DeviceLevel_Request__rosidl_typesupport_introspection_c__DeviceLevel_Request_message_members = {
  "clean_msgs__srv",  // message namespace
  "DeviceLevel_Request",  // message name
  2,  // number of fields
  sizeof(clean_msgs__srv__DeviceLevel_Request),
  DeviceLevel_Request__rosidl_typesupport_introspection_c__DeviceLevel_Request_message_member_array,  // message members
  DeviceLevel_Request__rosidl_typesupport_introspection_c__DeviceLevel_Request_init_function,  // function to initialize message memory (memory has to be allocated)
  DeviceLevel_Request__rosidl_typesupport_introspection_c__DeviceLevel_Request_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t DeviceLevel_Request__rosidl_typesupport_introspection_c__DeviceLevel_Request_message_type_support_handle = {
  0,
  &DeviceLevel_Request__rosidl_typesupport_introspection_c__DeviceLevel_Request_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_clean_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, clean_msgs, srv, DeviceLevel_Request)() {
  DeviceLevel_Request__rosidl_typesupport_introspection_c__DeviceLevel_Request_message_member_array[1].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, clean_msgs, msg, DeviceInfo)();
  if (!DeviceLevel_Request__rosidl_typesupport_introspection_c__DeviceLevel_Request_message_type_support_handle.typesupport_identifier) {
    DeviceLevel_Request__rosidl_typesupport_introspection_c__DeviceLevel_Request_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &DeviceLevel_Request__rosidl_typesupport_introspection_c__DeviceLevel_Request_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "clean_msgs/srv/detail/device_level__rosidl_typesupport_introspection_c.h"
// already included above
// #include "clean_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "rosidl_typesupport_introspection_c/field_types.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
// already included above
// #include "rosidl_typesupport_introspection_c/message_introspection.h"
// already included above
// #include "clean_msgs/srv/detail/device_level__functions.h"
// already included above
// #include "clean_msgs/srv/detail/device_level__struct.h"


// Include directives for member types
// Member `device_info`
// already included above
// #include "clean_msgs/msg/device_info.h"
// Member `device_info`
// already included above
// #include "clean_msgs/msg/detail/device_info__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void DeviceLevel_Response__rosidl_typesupport_introspection_c__DeviceLevel_Response_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  clean_msgs__srv__DeviceLevel_Response__init(message_memory);
}

void DeviceLevel_Response__rosidl_typesupport_introspection_c__DeviceLevel_Response_fini_function(void * message_memory)
{
  clean_msgs__srv__DeviceLevel_Response__fini(message_memory);
}

size_t DeviceLevel_Response__rosidl_typesupport_introspection_c__size_function__DeviceInfo__device_info(
  const void * untyped_member)
{
  const clean_msgs__msg__DeviceInfo__Sequence * member =
    (const clean_msgs__msg__DeviceInfo__Sequence *)(untyped_member);
  return member->size;
}

const void * DeviceLevel_Response__rosidl_typesupport_introspection_c__get_const_function__DeviceInfo__device_info(
  const void * untyped_member, size_t index)
{
  const clean_msgs__msg__DeviceInfo__Sequence * member =
    (const clean_msgs__msg__DeviceInfo__Sequence *)(untyped_member);
  return &member->data[index];
}

void * DeviceLevel_Response__rosidl_typesupport_introspection_c__get_function__DeviceInfo__device_info(
  void * untyped_member, size_t index)
{
  clean_msgs__msg__DeviceInfo__Sequence * member =
    (clean_msgs__msg__DeviceInfo__Sequence *)(untyped_member);
  return &member->data[index];
}

bool DeviceLevel_Response__rosidl_typesupport_introspection_c__resize_function__DeviceInfo__device_info(
  void * untyped_member, size_t size)
{
  clean_msgs__msg__DeviceInfo__Sequence * member =
    (clean_msgs__msg__DeviceInfo__Sequence *)(untyped_member);
  clean_msgs__msg__DeviceInfo__Sequence__fini(member);
  return clean_msgs__msg__DeviceInfo__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember DeviceLevel_Response__rosidl_typesupport_introspection_c__DeviceLevel_Response_message_member_array[2] = {
  {
    "result",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(clean_msgs__srv__DeviceLevel_Response, result),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "device_info",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(clean_msgs__srv__DeviceLevel_Response, device_info),  // bytes offset in struct
    NULL,  // default value
    DeviceLevel_Response__rosidl_typesupport_introspection_c__size_function__DeviceInfo__device_info,  // size() function pointer
    DeviceLevel_Response__rosidl_typesupport_introspection_c__get_const_function__DeviceInfo__device_info,  // get_const(index) function pointer
    DeviceLevel_Response__rosidl_typesupport_introspection_c__get_function__DeviceInfo__device_info,  // get(index) function pointer
    DeviceLevel_Response__rosidl_typesupport_introspection_c__resize_function__DeviceInfo__device_info  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers DeviceLevel_Response__rosidl_typesupport_introspection_c__DeviceLevel_Response_message_members = {
  "clean_msgs__srv",  // message namespace
  "DeviceLevel_Response",  // message name
  2,  // number of fields
  sizeof(clean_msgs__srv__DeviceLevel_Response),
  DeviceLevel_Response__rosidl_typesupport_introspection_c__DeviceLevel_Response_message_member_array,  // message members
  DeviceLevel_Response__rosidl_typesupport_introspection_c__DeviceLevel_Response_init_function,  // function to initialize message memory (memory has to be allocated)
  DeviceLevel_Response__rosidl_typesupport_introspection_c__DeviceLevel_Response_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t DeviceLevel_Response__rosidl_typesupport_introspection_c__DeviceLevel_Response_message_type_support_handle = {
  0,
  &DeviceLevel_Response__rosidl_typesupport_introspection_c__DeviceLevel_Response_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_clean_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, clean_msgs, srv, DeviceLevel_Response)() {
  DeviceLevel_Response__rosidl_typesupport_introspection_c__DeviceLevel_Response_message_member_array[1].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, clean_msgs, msg, DeviceInfo)();
  if (!DeviceLevel_Response__rosidl_typesupport_introspection_c__DeviceLevel_Response_message_type_support_handle.typesupport_identifier) {
    DeviceLevel_Response__rosidl_typesupport_introspection_c__DeviceLevel_Response_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &DeviceLevel_Response__rosidl_typesupport_introspection_c__DeviceLevel_Response_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

#include "rosidl_runtime_c/service_type_support_struct.h"
// already included above
// #include "clean_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "clean_msgs/srv/detail/device_level__rosidl_typesupport_introspection_c.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/service_introspection.h"

// this is intentionally not const to allow initialization later to prevent an initialization race
static rosidl_typesupport_introspection_c__ServiceMembers clean_msgs__srv__detail__device_level__rosidl_typesupport_introspection_c__DeviceLevel_service_members = {
  "clean_msgs__srv",  // service namespace
  "DeviceLevel",  // service name
  // these two fields are initialized below on the first access
  NULL,  // request message
  // clean_msgs__srv__detail__device_level__rosidl_typesupport_introspection_c__DeviceLevel_Request_message_type_support_handle,
  NULL  // response message
  // clean_msgs__srv__detail__device_level__rosidl_typesupport_introspection_c__DeviceLevel_Response_message_type_support_handle
};

static rosidl_service_type_support_t clean_msgs__srv__detail__device_level__rosidl_typesupport_introspection_c__DeviceLevel_service_type_support_handle = {
  0,
  &clean_msgs__srv__detail__device_level__rosidl_typesupport_introspection_c__DeviceLevel_service_members,
  get_service_typesupport_handle_function,
};

// Forward declaration of request/response type support functions
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, clean_msgs, srv, DeviceLevel_Request)();

const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, clean_msgs, srv, DeviceLevel_Response)();

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_clean_msgs
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(rosidl_typesupport_introspection_c, clean_msgs, srv, DeviceLevel)() {
  if (!clean_msgs__srv__detail__device_level__rosidl_typesupport_introspection_c__DeviceLevel_service_type_support_handle.typesupport_identifier) {
    clean_msgs__srv__detail__device_level__rosidl_typesupport_introspection_c__DeviceLevel_service_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  rosidl_typesupport_introspection_c__ServiceMembers * service_members =
    (rosidl_typesupport_introspection_c__ServiceMembers *)clean_msgs__srv__detail__device_level__rosidl_typesupport_introspection_c__DeviceLevel_service_type_support_handle.data;

  if (!service_members->request_members_) {
    service_members->request_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, clean_msgs, srv, DeviceLevel_Request)()->data;
  }
  if (!service_members->response_members_) {
    service_members->response_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, clean_msgs, srv, DeviceLevel_Response)()->data;
  }

  return &clean_msgs__srv__detail__device_level__rosidl_typesupport_introspection_c__DeviceLevel_service_type_support_handle;
}
