// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from clean_msgs:srv/PathUpdate.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__PATH_UPDATE__STRUCT_H_
#define CLEAN_MSGS__SRV__DETAIL__PATH_UPDATE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'id'
// Member 'map_id'
// Member 'path_name'
// Member 'cleaning_mode_id'
#include "rosidl_runtime_c/string.h"
// Member 'points'
#include "geometry_msgs/msg/detail/point__struct.h"

// Struct defined in srv/PathUpdate in the package clean_msgs.
typedef struct clean_msgs__srv__PathUpdate_Request
{
  rosidl_runtime_c__String id;
  rosidl_runtime_c__String map_id;
  rosidl_runtime_c__String path_name;
  rosidl_runtime_c__String cleaning_mode_id;
  geometry_msgs__msg__Point__Sequence points;
} clean_msgs__srv__PathUpdate_Request;

// Struct for a sequence of clean_msgs__srv__PathUpdate_Request.
typedef struct clean_msgs__srv__PathUpdate_Request__Sequence
{
  clean_msgs__srv__PathUpdate_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} clean_msgs__srv__PathUpdate_Request__Sequence;


// Constants defined in the message

// Struct defined in srv/PathUpdate in the package clean_msgs.
typedef struct clean_msgs__srv__PathUpdate_Response
{
  uint32_t result;
} clean_msgs__srv__PathUpdate_Response;

// Struct for a sequence of clean_msgs__srv__PathUpdate_Response.
typedef struct clean_msgs__srv__PathUpdate_Response__Sequence
{
  clean_msgs__srv__PathUpdate_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} clean_msgs__srv__PathUpdate_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CLEAN_MSGS__SRV__DETAIL__PATH_UPDATE__STRUCT_H_
