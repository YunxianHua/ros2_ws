// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from clean_msgs:srv/TaskReportGet.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__TASK_REPORT_GET__STRUCT_H_
#define CLEAN_MSGS__SRV__DETAIL__TASK_REPORT_GET__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'FINISHED_TYPE_UNKNOWN'.
enum
{
  clean_msgs__srv__TaskReportGet_Request__FINISHED_TYPE_UNKNOWN = 0ul
};

/// Constant 'FINISHED_TYPE_NORMAL'.
enum
{
  clean_msgs__srv__TaskReportGet_Request__FINISHED_TYPE_NORMAL = 1ul
};

/// Constant 'FINISHED_TYPE_EXCEPTION'.
enum
{
  clean_msgs__srv__TaskReportGet_Request__FINISHED_TYPE_EXCEPTION = 2ul
};

/// Constant 'FINISHED_TYPE_MANUAL'.
enum
{
  clean_msgs__srv__TaskReportGet_Request__FINISHED_TYPE_MANUAL = 3ul
};

/// Constant 'FINISHED_TYPE_CONTIUNE_ABANDON'.
enum
{
  clean_msgs__srv__TaskReportGet_Request__FINISHED_TYPE_CONTIUNE_ABANDON = 4ul
};

// Include directives for member types
// Member 'task_exe_id'
#include "rosidl_runtime_c/string.h"

// Struct defined in srv/TaskReportGet in the package clean_msgs.
typedef struct clean_msgs__srv__TaskReportGet_Request
{
  rosidl_runtime_c__String task_exe_id;
} clean_msgs__srv__TaskReportGet_Request;

// Struct for a sequence of clean_msgs__srv__TaskReportGet_Request.
typedef struct clean_msgs__srv__TaskReportGet_Request__Sequence
{
  clean_msgs__srv__TaskReportGet_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} clean_msgs__srv__TaskReportGet_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'task_exe_id'
// Member 'task_name'
// Member 'cleaning_mode_id'
// Member 'cleaning_mode_name'
// already included above
// #include "rosidl_runtime_c/string.h"

// Struct defined in srv/TaskReportGet in the package clean_msgs.
typedef struct clean_msgs__srv__TaskReportGet_Response
{
  uint32_t result;
  rosidl_runtime_c__String task_exe_id;
  rosidl_runtime_c__String task_name;
  rosidl_runtime_c__String cleaning_mode_id;
  rosidl_runtime_c__String cleaning_mode_name;
  uint32_t actual_loop;
  uint32_t loop;
  uint32_t start_utc_time;
  uint32_t end_utc_time;
  uint32_t finished_type;
  uint32_t supply_times;
  uint32_t spent_time;
  float spent_water;
  float spent_battery;
  uint32_t actual_area;
  float finish_per;
  uint32_t cleaning_efficiency;
} clean_msgs__srv__TaskReportGet_Response;

// Struct for a sequence of clean_msgs__srv__TaskReportGet_Response.
typedef struct clean_msgs__srv__TaskReportGet_Response__Sequence
{
  clean_msgs__srv__TaskReportGet_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} clean_msgs__srv__TaskReportGet_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CLEAN_MSGS__SRV__DETAIL__TASK_REPORT_GET__STRUCT_H_
