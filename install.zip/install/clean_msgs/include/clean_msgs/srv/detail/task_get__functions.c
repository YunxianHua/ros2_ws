// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from clean_msgs:srv/TaskGet.idl
// generated code does not contain a copyright notice
#include "clean_msgs/srv/detail/task_get__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"

// Include directives for member types
// Member `task_id`
#include "rosidl_runtime_c/string_functions.h"

bool
clean_msgs__srv__TaskGet_Request__init(clean_msgs__srv__TaskGet_Request * msg)
{
  if (!msg) {
    return false;
  }
  // type
  // task_id
  if (!rosidl_runtime_c__String__init(&msg->task_id)) {
    clean_msgs__srv__TaskGet_Request__fini(msg);
    return false;
  }
  return true;
}

void
clean_msgs__srv__TaskGet_Request__fini(clean_msgs__srv__TaskGet_Request * msg)
{
  if (!msg) {
    return;
  }
  // type
  // task_id
  rosidl_runtime_c__String__fini(&msg->task_id);
}

bool
clean_msgs__srv__TaskGet_Request__are_equal(const clean_msgs__srv__TaskGet_Request * lhs, const clean_msgs__srv__TaskGet_Request * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // type
  if (lhs->type != rhs->type) {
    return false;
  }
  // task_id
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->task_id), &(rhs->task_id)))
  {
    return false;
  }
  return true;
}

bool
clean_msgs__srv__TaskGet_Request__copy(
  const clean_msgs__srv__TaskGet_Request * input,
  clean_msgs__srv__TaskGet_Request * output)
{
  if (!input || !output) {
    return false;
  }
  // type
  output->type = input->type;
  // task_id
  if (!rosidl_runtime_c__String__copy(
      &(input->task_id), &(output->task_id)))
  {
    return false;
  }
  return true;
}

clean_msgs__srv__TaskGet_Request *
clean_msgs__srv__TaskGet_Request__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  clean_msgs__srv__TaskGet_Request * msg = (clean_msgs__srv__TaskGet_Request *)allocator.allocate(sizeof(clean_msgs__srv__TaskGet_Request), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(clean_msgs__srv__TaskGet_Request));
  bool success = clean_msgs__srv__TaskGet_Request__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
clean_msgs__srv__TaskGet_Request__destroy(clean_msgs__srv__TaskGet_Request * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    clean_msgs__srv__TaskGet_Request__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
clean_msgs__srv__TaskGet_Request__Sequence__init(clean_msgs__srv__TaskGet_Request__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  clean_msgs__srv__TaskGet_Request * data = NULL;

  if (size) {
    data = (clean_msgs__srv__TaskGet_Request *)allocator.zero_allocate(size, sizeof(clean_msgs__srv__TaskGet_Request), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = clean_msgs__srv__TaskGet_Request__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        clean_msgs__srv__TaskGet_Request__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
clean_msgs__srv__TaskGet_Request__Sequence__fini(clean_msgs__srv__TaskGet_Request__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      clean_msgs__srv__TaskGet_Request__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

clean_msgs__srv__TaskGet_Request__Sequence *
clean_msgs__srv__TaskGet_Request__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  clean_msgs__srv__TaskGet_Request__Sequence * array = (clean_msgs__srv__TaskGet_Request__Sequence *)allocator.allocate(sizeof(clean_msgs__srv__TaskGet_Request__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = clean_msgs__srv__TaskGet_Request__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
clean_msgs__srv__TaskGet_Request__Sequence__destroy(clean_msgs__srv__TaskGet_Request__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    clean_msgs__srv__TaskGet_Request__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
clean_msgs__srv__TaskGet_Request__Sequence__are_equal(const clean_msgs__srv__TaskGet_Request__Sequence * lhs, const clean_msgs__srv__TaskGet_Request__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!clean_msgs__srv__TaskGet_Request__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
clean_msgs__srv__TaskGet_Request__Sequence__copy(
  const clean_msgs__srv__TaskGet_Request__Sequence * input,
  clean_msgs__srv__TaskGet_Request__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(clean_msgs__srv__TaskGet_Request);
    clean_msgs__srv__TaskGet_Request * data =
      (clean_msgs__srv__TaskGet_Request *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!clean_msgs__srv__TaskGet_Request__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          clean_msgs__srv__TaskGet_Request__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!clean_msgs__srv__TaskGet_Request__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}


// Include directives for member types
// Member `id`
// Member `name`
// Member `task_cleaning_mode_id`
// Member `task_cleaning_mode_name`
// Member `task_start_time`
// Member `task_suspend_time`
// already included above
// #include "rosidl_runtime_c/string_functions.h"
// Member `subtasks`
#include "clean_msgs/msg/detail/sub_task_info__functions.h"

bool
clean_msgs__srv__TaskGet_Response__init(clean_msgs__srv__TaskGet_Response * msg)
{
  if (!msg) {
    return false;
  }
  // result
  // id
  if (!rosidl_runtime_c__String__init(&msg->id)) {
    clean_msgs__srv__TaskGet_Response__fini(msg);
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__init(&msg->name)) {
    clean_msgs__srv__TaskGet_Response__fini(msg);
    return false;
  }
  // subtasks
  if (!clean_msgs__msg__SubTaskInfo__Sequence__init(&msg->subtasks, 0)) {
    clean_msgs__srv__TaskGet_Response__fini(msg);
    return false;
  }
  // task_cleaning_mode_id
  if (!rosidl_runtime_c__String__init(&msg->task_cleaning_mode_id)) {
    clean_msgs__srv__TaskGet_Response__fini(msg);
    return false;
  }
  // task_cleaning_mode_name
  if (!rosidl_runtime_c__String__init(&msg->task_cleaning_mode_name)) {
    clean_msgs__srv__TaskGet_Response__fini(msg);
    return false;
  }
  // all_loop_count
  // cur_loop_count
  // task_start_time
  if (!rosidl_runtime_c__String__init(&msg->task_start_time)) {
    clean_msgs__srv__TaskGet_Response__fini(msg);
    return false;
  }
  // task_suspend_time
  if (!rosidl_runtime_c__String__init(&msg->task_suspend_time)) {
    clean_msgs__srv__TaskGet_Response__fini(msg);
    return false;
  }
  return true;
}

void
clean_msgs__srv__TaskGet_Response__fini(clean_msgs__srv__TaskGet_Response * msg)
{
  if (!msg) {
    return;
  }
  // result
  // id
  rosidl_runtime_c__String__fini(&msg->id);
  // name
  rosidl_runtime_c__String__fini(&msg->name);
  // subtasks
  clean_msgs__msg__SubTaskInfo__Sequence__fini(&msg->subtasks);
  // task_cleaning_mode_id
  rosidl_runtime_c__String__fini(&msg->task_cleaning_mode_id);
  // task_cleaning_mode_name
  rosidl_runtime_c__String__fini(&msg->task_cleaning_mode_name);
  // all_loop_count
  // cur_loop_count
  // task_start_time
  rosidl_runtime_c__String__fini(&msg->task_start_time);
  // task_suspend_time
  rosidl_runtime_c__String__fini(&msg->task_suspend_time);
}

bool
clean_msgs__srv__TaskGet_Response__are_equal(const clean_msgs__srv__TaskGet_Response * lhs, const clean_msgs__srv__TaskGet_Response * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // result
  if (lhs->result != rhs->result) {
    return false;
  }
  // id
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->id), &(rhs->id)))
  {
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->name), &(rhs->name)))
  {
    return false;
  }
  // subtasks
  if (!clean_msgs__msg__SubTaskInfo__Sequence__are_equal(
      &(lhs->subtasks), &(rhs->subtasks)))
  {
    return false;
  }
  // task_cleaning_mode_id
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->task_cleaning_mode_id), &(rhs->task_cleaning_mode_id)))
  {
    return false;
  }
  // task_cleaning_mode_name
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->task_cleaning_mode_name), &(rhs->task_cleaning_mode_name)))
  {
    return false;
  }
  // all_loop_count
  if (lhs->all_loop_count != rhs->all_loop_count) {
    return false;
  }
  // cur_loop_count
  if (lhs->cur_loop_count != rhs->cur_loop_count) {
    return false;
  }
  // task_start_time
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->task_start_time), &(rhs->task_start_time)))
  {
    return false;
  }
  // task_suspend_time
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->task_suspend_time), &(rhs->task_suspend_time)))
  {
    return false;
  }
  return true;
}

bool
clean_msgs__srv__TaskGet_Response__copy(
  const clean_msgs__srv__TaskGet_Response * input,
  clean_msgs__srv__TaskGet_Response * output)
{
  if (!input || !output) {
    return false;
  }
  // result
  output->result = input->result;
  // id
  if (!rosidl_runtime_c__String__copy(
      &(input->id), &(output->id)))
  {
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__copy(
      &(input->name), &(output->name)))
  {
    return false;
  }
  // subtasks
  if (!clean_msgs__msg__SubTaskInfo__Sequence__copy(
      &(input->subtasks), &(output->subtasks)))
  {
    return false;
  }
  // task_cleaning_mode_id
  if (!rosidl_runtime_c__String__copy(
      &(input->task_cleaning_mode_id), &(output->task_cleaning_mode_id)))
  {
    return false;
  }
  // task_cleaning_mode_name
  if (!rosidl_runtime_c__String__copy(
      &(input->task_cleaning_mode_name), &(output->task_cleaning_mode_name)))
  {
    return false;
  }
  // all_loop_count
  output->all_loop_count = input->all_loop_count;
  // cur_loop_count
  output->cur_loop_count = input->cur_loop_count;
  // task_start_time
  if (!rosidl_runtime_c__String__copy(
      &(input->task_start_time), &(output->task_start_time)))
  {
    return false;
  }
  // task_suspend_time
  if (!rosidl_runtime_c__String__copy(
      &(input->task_suspend_time), &(output->task_suspend_time)))
  {
    return false;
  }
  return true;
}

clean_msgs__srv__TaskGet_Response *
clean_msgs__srv__TaskGet_Response__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  clean_msgs__srv__TaskGet_Response * msg = (clean_msgs__srv__TaskGet_Response *)allocator.allocate(sizeof(clean_msgs__srv__TaskGet_Response), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(clean_msgs__srv__TaskGet_Response));
  bool success = clean_msgs__srv__TaskGet_Response__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
clean_msgs__srv__TaskGet_Response__destroy(clean_msgs__srv__TaskGet_Response * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    clean_msgs__srv__TaskGet_Response__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
clean_msgs__srv__TaskGet_Response__Sequence__init(clean_msgs__srv__TaskGet_Response__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  clean_msgs__srv__TaskGet_Response * data = NULL;

  if (size) {
    data = (clean_msgs__srv__TaskGet_Response *)allocator.zero_allocate(size, sizeof(clean_msgs__srv__TaskGet_Response), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = clean_msgs__srv__TaskGet_Response__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        clean_msgs__srv__TaskGet_Response__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
clean_msgs__srv__TaskGet_Response__Sequence__fini(clean_msgs__srv__TaskGet_Response__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      clean_msgs__srv__TaskGet_Response__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

clean_msgs__srv__TaskGet_Response__Sequence *
clean_msgs__srv__TaskGet_Response__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  clean_msgs__srv__TaskGet_Response__Sequence * array = (clean_msgs__srv__TaskGet_Response__Sequence *)allocator.allocate(sizeof(clean_msgs__srv__TaskGet_Response__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = clean_msgs__srv__TaskGet_Response__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
clean_msgs__srv__TaskGet_Response__Sequence__destroy(clean_msgs__srv__TaskGet_Response__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    clean_msgs__srv__TaskGet_Response__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
clean_msgs__srv__TaskGet_Response__Sequence__are_equal(const clean_msgs__srv__TaskGet_Response__Sequence * lhs, const clean_msgs__srv__TaskGet_Response__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!clean_msgs__srv__TaskGet_Response__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
clean_msgs__srv__TaskGet_Response__Sequence__copy(
  const clean_msgs__srv__TaskGet_Response__Sequence * input,
  clean_msgs__srv__TaskGet_Response__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(clean_msgs__srv__TaskGet_Response);
    clean_msgs__srv__TaskGet_Response * data =
      (clean_msgs__srv__TaskGet_Response *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!clean_msgs__srv__TaskGet_Response__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          clean_msgs__srv__TaskGet_Response__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!clean_msgs__srv__TaskGet_Response__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
