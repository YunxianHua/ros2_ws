// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from clean_msgs:srv/DeviceLevel.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__DEVICE_LEVEL__TRAITS_HPP_
#define CLEAN_MSGS__SRV__DETAIL__DEVICE_LEVEL__TRAITS_HPP_

#include "clean_msgs/srv/detail/device_level__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

// Include directives for member types
// Member 'device_info'
#include "clean_msgs/msg/detail/device_info__traits.hpp"

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<clean_msgs::srv::DeviceLevel_Request>()
{
  return "clean_msgs::srv::DeviceLevel_Request";
}

template<>
inline const char * name<clean_msgs::srv::DeviceLevel_Request>()
{
  return "clean_msgs/srv/DeviceLevel_Request";
}

template<>
struct has_fixed_size<clean_msgs::srv::DeviceLevel_Request>
  : std::integral_constant<bool, has_fixed_size<clean_msgs::msg::DeviceInfo>::value> {};

template<>
struct has_bounded_size<clean_msgs::srv::DeviceLevel_Request>
  : std::integral_constant<bool, has_bounded_size<clean_msgs::msg::DeviceInfo>::value> {};

template<>
struct is_message<clean_msgs::srv::DeviceLevel_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<clean_msgs::srv::DeviceLevel_Response>()
{
  return "clean_msgs::srv::DeviceLevel_Response";
}

template<>
inline const char * name<clean_msgs::srv::DeviceLevel_Response>()
{
  return "clean_msgs/srv/DeviceLevel_Response";
}

template<>
struct has_fixed_size<clean_msgs::srv::DeviceLevel_Response>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<clean_msgs::srv::DeviceLevel_Response>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<clean_msgs::srv::DeviceLevel_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<clean_msgs::srv::DeviceLevel>()
{
  return "clean_msgs::srv::DeviceLevel";
}

template<>
inline const char * name<clean_msgs::srv::DeviceLevel>()
{
  return "clean_msgs/srv/DeviceLevel";
}

template<>
struct has_fixed_size<clean_msgs::srv::DeviceLevel>
  : std::integral_constant<
    bool,
    has_fixed_size<clean_msgs::srv::DeviceLevel_Request>::value &&
    has_fixed_size<clean_msgs::srv::DeviceLevel_Response>::value
  >
{
};

template<>
struct has_bounded_size<clean_msgs::srv::DeviceLevel>
  : std::integral_constant<
    bool,
    has_bounded_size<clean_msgs::srv::DeviceLevel_Request>::value &&
    has_bounded_size<clean_msgs::srv::DeviceLevel_Response>::value
  >
{
};

template<>
struct is_service<clean_msgs::srv::DeviceLevel>
  : std::true_type
{
};

template<>
struct is_service_request<clean_msgs::srv::DeviceLevel_Request>
  : std::true_type
{
};

template<>
struct is_service_response<clean_msgs::srv::DeviceLevel_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // CLEAN_MSGS__SRV__DETAIL__DEVICE_LEVEL__TRAITS_HPP_
