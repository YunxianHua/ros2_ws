// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from clean_msgs:srv/PointDel.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__POINT_DEL__STRUCT_H_
#define CLEAN_MSGS__SRV__DETAIL__POINT_DEL__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'id'
// Member 'map_id'
#include "rosidl_runtime_c/string.h"

// Struct defined in srv/PointDel in the package clean_msgs.
typedef struct clean_msgs__srv__PointDel_Request
{
  rosidl_runtime_c__String id;
  rosidl_runtime_c__String map_id;
} clean_msgs__srv__PointDel_Request;

// Struct for a sequence of clean_msgs__srv__PointDel_Request.
typedef struct clean_msgs__srv__PointDel_Request__Sequence
{
  clean_msgs__srv__PointDel_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} clean_msgs__srv__PointDel_Request__Sequence;


// Constants defined in the message

// Struct defined in srv/PointDel in the package clean_msgs.
typedef struct clean_msgs__srv__PointDel_Response
{
  uint32_t result;
} clean_msgs__srv__PointDel_Response;

// Struct for a sequence of clean_msgs__srv__PointDel_Response.
typedef struct clean_msgs__srv__PointDel_Response__Sequence
{
  clean_msgs__srv__PointDel_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} clean_msgs__srv__PointDel_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CLEAN_MSGS__SRV__DETAIL__POINT_DEL__STRUCT_H_
