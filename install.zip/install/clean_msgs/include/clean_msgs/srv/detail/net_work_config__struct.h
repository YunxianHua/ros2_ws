// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from clean_msgs:srv/NetWorkConfig.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__NET_WORK_CONFIG__STRUCT_H_
#define CLEAN_MSGS__SRV__DETAIL__NET_WORK_CONFIG__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'NETWOTK_TYPE_CELLULAR'.
enum
{
  clean_msgs__srv__NetWorkConfig_Request__NETWOTK_TYPE_CELLULAR = 0ul
};

/// Constant 'NETWOTK_TYPE_WIRELESS'.
enum
{
  clean_msgs__srv__NetWorkConfig_Request__NETWOTK_TYPE_WIRELESS = 1ul
};

/// Constant 'NETWOTK_TYPE_HOTSPOT'.
enum
{
  clean_msgs__srv__NetWorkConfig_Request__NETWOTK_TYPE_HOTSPOT = 2ul
};

/// Constant 'NETWORK_TYPE_ALL'.
enum
{
  clean_msgs__srv__NetWorkConfig_Request__NETWORK_TYPE_ALL = 3ul
};

/// Constant 'NETWORK_CMD_CLOSE'.
enum
{
  clean_msgs__srv__NetWorkConfig_Request__NETWORK_CMD_CLOSE = 0ul
};

/// Constant 'NETWORK_CMD_OPEN'.
enum
{
  clean_msgs__srv__NetWorkConfig_Request__NETWORK_CMD_OPEN = 1ul
};

/// Constant 'NETWORK_CMD_GET'.
enum
{
  clean_msgs__srv__NetWorkConfig_Request__NETWORK_CMD_GET = 2ul
};

/// Constant 'NETWORK_CMD_WIRELESS_LIST'.
enum
{
  clean_msgs__srv__NetWorkConfig_Request__NETWORK_CMD_WIRELESS_LIST = 4ul
};

/// Constant 'NETWORK_CMD_CONNECT'.
enum
{
  clean_msgs__srv__NetWorkConfig_Request__NETWORK_CMD_CONNECT = 5ul
};

// Include directives for member types
// Member 'wireless_name'
// Member 'wireless_passwd'
#include "rosidl_runtime_c/string.h"

// Struct defined in srv/NetWorkConfig in the package clean_msgs.
typedef struct clean_msgs__srv__NetWorkConfig_Request
{
  uint32_t cmd;
  uint32_t type;
  rosidl_runtime_c__String wireless_name;
  rosidl_runtime_c__String wireless_passwd;
} clean_msgs__srv__NetWorkConfig_Request;

// Struct for a sequence of clean_msgs__srv__NetWorkConfig_Request.
typedef struct clean_msgs__srv__NetWorkConfig_Request__Sequence
{
  clean_msgs__srv__NetWorkConfig_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} clean_msgs__srv__NetWorkConfig_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'wireless_infos'
#include "clean_msgs/msg/detail/wireless_network__struct.h"
// Member 'hotspot_name'
// Member 'hostspot_passwd'
// already included above
// #include "rosidl_runtime_c/string.h"

// Struct defined in srv/NetWorkConfig in the package clean_msgs.
typedef struct clean_msgs__srv__NetWorkConfig_Response
{
  uint32_t result;
  bool cellular_net_enable;
  uint32_t cellular_provider;
  uint32_t cellular_standard;
  uint32_t cellular_signal;
  bool wireless_net_enable;
  clean_msgs__msg__WirelessNetwork__Sequence wireless_infos;
  bool hotspot_enable;
  rosidl_runtime_c__String hotspot_name;
  rosidl_runtime_c__String hostspot_passwd;
} clean_msgs__srv__NetWorkConfig_Response;

// Struct for a sequence of clean_msgs__srv__NetWorkConfig_Response.
typedef struct clean_msgs__srv__NetWorkConfig_Response__Sequence
{
  clean_msgs__srv__NetWorkConfig_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} clean_msgs__srv__NetWorkConfig_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CLEAN_MSGS__SRV__DETAIL__NET_WORK_CONFIG__STRUCT_H_
