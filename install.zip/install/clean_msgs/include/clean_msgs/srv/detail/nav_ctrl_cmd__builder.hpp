// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from clean_msgs:srv/NavCtrlCmd.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__NAV_CTRL_CMD__BUILDER_HPP_
#define CLEAN_MSGS__SRV__DETAIL__NAV_CTRL_CMD__BUILDER_HPP_

#include "clean_msgs/srv/detail/nav_ctrl_cmd__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_NavCtrlCmd_Request_cmd
{
public:
  Init_NavCtrlCmd_Request_cmd()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::clean_msgs::srv::NavCtrlCmd_Request cmd(::clean_msgs::srv::NavCtrlCmd_Request::_cmd_type arg)
  {
    msg_.cmd = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::NavCtrlCmd_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::NavCtrlCmd_Request>()
{
  return clean_msgs::srv::builder::Init_NavCtrlCmd_Request_cmd();
}

}  // namespace clean_msgs


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_NavCtrlCmd_Response_result
{
public:
  Init_NavCtrlCmd_Response_result()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::clean_msgs::srv::NavCtrlCmd_Response result(::clean_msgs::srv::NavCtrlCmd_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::NavCtrlCmd_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::NavCtrlCmd_Response>()
{
  return clean_msgs::srv::builder::Init_NavCtrlCmd_Response_result();
}

}  // namespace clean_msgs

#endif  // CLEAN_MSGS__SRV__DETAIL__NAV_CTRL_CMD__BUILDER_HPP_
