// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from clean_msgs:srv/DeviceControl.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__DEVICE_CONTROL__STRUCT_H_
#define CLEAN_MSGS__SRV__DETAIL__DEVICE_CONTROL__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'OPEN_WATER'.
enum
{
  clean_msgs__srv__DeviceControl_Request__OPEN_WATER = 1ul
};

/// Constant 'STOP_WATER'.
enum
{
  clean_msgs__srv__DeviceControl_Request__STOP_WATER = 2ul
};

/// Constant 'OPEN_DEVICE'.
enum
{
  clean_msgs__srv__DeviceControl_Request__OPEN_DEVICE = 3ul
};

/// Constant 'OPEN_BRUSH_ROLL'.
enum
{
  clean_msgs__srv__DeviceControl_Request__OPEN_BRUSH_ROLL = 4ul
};

/// Constant 'ADJUST_SUCTION_POWER'.
enum
{
  clean_msgs__srv__DeviceControl_Request__ADJUST_SUCTION_POWER = 5ul
};

/// Constant 'STOP_SUCTION'.
enum
{
  clean_msgs__srv__DeviceControl_Request__STOP_SUCTION = 6ul
};

/// Constant 'STOP_BRUSH_ROLL'.
enum
{
  clean_msgs__srv__DeviceControl_Request__STOP_BRUSH_ROLL = 7ul
};

/// Constant 'STOP_BRUSH_SIDE'.
enum
{
  clean_msgs__srv__DeviceControl_Request__STOP_BRUSH_SIDE = 8ul
};

/// Constant 'DEPLOY_DEVICE'.
enum
{
  clean_msgs__srv__DeviceControl_Request__DEPLOY_DEVICE = 9ul
};

/// Constant 'LIFT_BRUSH'.
enum
{
  clean_msgs__srv__DeviceControl_Request__LIFT_BRUSH = 10ul
};

/// Constant 'LIFT_SQUEEGEE'.
enum
{
  clean_msgs__srv__DeviceControl_Request__LIFT_SQUEEGEE = 11ul
};

/// Constant 'LIFT_DEVICE'.
enum
{
  clean_msgs__srv__DeviceControl_Request__LIFT_DEVICE = 12ul
};

/// Constant 'COLLECT_SUCTION'.
enum
{
  clean_msgs__srv__DeviceControl_Request__COLLECT_SUCTION = 13ul
};

/// Constant 'SELF_CLEAN'.
enum
{
  clean_msgs__srv__DeviceControl_Request__SELF_CLEAN = 14ul
};

/// Constant 'SEWAGE_CTL'.
enum
{
  clean_msgs__srv__DeviceControl_Request__SEWAGE_CTL = 15ul
};

// Struct defined in srv/DeviceControl in the package clean_msgs.
typedef struct clean_msgs__srv__DeviceControl_Request
{
  uint32_t cmd;
  bool is_delay;
} clean_msgs__srv__DeviceControl_Request;

// Struct for a sequence of clean_msgs__srv__DeviceControl_Request.
typedef struct clean_msgs__srv__DeviceControl_Request__Sequence
{
  clean_msgs__srv__DeviceControl_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} clean_msgs__srv__DeviceControl_Request__Sequence;


// Constants defined in the message

// Struct defined in srv/DeviceControl in the package clean_msgs.
typedef struct clean_msgs__srv__DeviceControl_Response
{
  uint32_t result;
} clean_msgs__srv__DeviceControl_Response;

// Struct for a sequence of clean_msgs__srv__DeviceControl_Response.
typedef struct clean_msgs__srv__DeviceControl_Response__Sequence
{
  clean_msgs__srv__DeviceControl_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} clean_msgs__srv__DeviceControl_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CLEAN_MSGS__SRV__DETAIL__DEVICE_CONTROL__STRUCT_H_
