// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from clean_msgs:srv/PathUpdate.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__PATH_UPDATE__BUILDER_HPP_
#define CLEAN_MSGS__SRV__DETAIL__PATH_UPDATE__BUILDER_HPP_

#include "clean_msgs/srv/detail/path_update__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_PathUpdate_Request_points
{
public:
  explicit Init_PathUpdate_Request_points(::clean_msgs::srv::PathUpdate_Request & msg)
  : msg_(msg)
  {}
  ::clean_msgs::srv::PathUpdate_Request points(::clean_msgs::srv::PathUpdate_Request::_points_type arg)
  {
    msg_.points = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::PathUpdate_Request msg_;
};

class Init_PathUpdate_Request_cleaning_mode_id
{
public:
  explicit Init_PathUpdate_Request_cleaning_mode_id(::clean_msgs::srv::PathUpdate_Request & msg)
  : msg_(msg)
  {}
  Init_PathUpdate_Request_points cleaning_mode_id(::clean_msgs::srv::PathUpdate_Request::_cleaning_mode_id_type arg)
  {
    msg_.cleaning_mode_id = std::move(arg);
    return Init_PathUpdate_Request_points(msg_);
  }

private:
  ::clean_msgs::srv::PathUpdate_Request msg_;
};

class Init_PathUpdate_Request_path_name
{
public:
  explicit Init_PathUpdate_Request_path_name(::clean_msgs::srv::PathUpdate_Request & msg)
  : msg_(msg)
  {}
  Init_PathUpdate_Request_cleaning_mode_id path_name(::clean_msgs::srv::PathUpdate_Request::_path_name_type arg)
  {
    msg_.path_name = std::move(arg);
    return Init_PathUpdate_Request_cleaning_mode_id(msg_);
  }

private:
  ::clean_msgs::srv::PathUpdate_Request msg_;
};

class Init_PathUpdate_Request_map_id
{
public:
  explicit Init_PathUpdate_Request_map_id(::clean_msgs::srv::PathUpdate_Request & msg)
  : msg_(msg)
  {}
  Init_PathUpdate_Request_path_name map_id(::clean_msgs::srv::PathUpdate_Request::_map_id_type arg)
  {
    msg_.map_id = std::move(arg);
    return Init_PathUpdate_Request_path_name(msg_);
  }

private:
  ::clean_msgs::srv::PathUpdate_Request msg_;
};

class Init_PathUpdate_Request_id
{
public:
  Init_PathUpdate_Request_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_PathUpdate_Request_map_id id(::clean_msgs::srv::PathUpdate_Request::_id_type arg)
  {
    msg_.id = std::move(arg);
    return Init_PathUpdate_Request_map_id(msg_);
  }

private:
  ::clean_msgs::srv::PathUpdate_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::PathUpdate_Request>()
{
  return clean_msgs::srv::builder::Init_PathUpdate_Request_id();
}

}  // namespace clean_msgs


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_PathUpdate_Response_result
{
public:
  Init_PathUpdate_Response_result()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::clean_msgs::srv::PathUpdate_Response result(::clean_msgs::srv::PathUpdate_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::PathUpdate_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::PathUpdate_Response>()
{
  return clean_msgs::srv::builder::Init_PathUpdate_Response_result();
}

}  // namespace clean_msgs

#endif  // CLEAN_MSGS__SRV__DETAIL__PATH_UPDATE__BUILDER_HPP_
