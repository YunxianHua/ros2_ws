// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from clean_msgs:srv/MapConfig.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__MAP_CONFIG__STRUCT_HPP_
#define CLEAN_MSGS__SRV__DETAIL__MAP_CONFIG__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


// Include directives for member types
// Member 'map_info'
#include "clean_msgs/msg/detail/map_info__struct.hpp"
// Member 'data_info'
#include "clean_msgs/msg/detail/map_data_update_info__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__clean_msgs__srv__MapConfig_Request __attribute__((deprecated))
#else
# define DEPRECATED__clean_msgs__srv__MapConfig_Request __declspec(deprecated)
#endif

namespace clean_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct MapConfig_Request_
{
  using Type = MapConfig_Request_<ContainerAllocator>;

  explicit MapConfig_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : map_info(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->cmd = 0ul;
      this->exec_id = "";
    }
  }

  explicit MapConfig_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : exec_id(_alloc),
    map_info(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->cmd = 0ul;
      this->exec_id = "";
    }
  }

  // field types and members
  using _cmd_type =
    uint32_t;
  _cmd_type cmd;
  using _exec_id_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _exec_id_type exec_id;
  using _map_info_type =
    clean_msgs::msg::MapInfo_<ContainerAllocator>;
  _map_info_type map_info;
  using _data_info_type =
    std::vector<clean_msgs::msg::MapDataUpdateInfo_<ContainerAllocator>, typename ContainerAllocator::template rebind<clean_msgs::msg::MapDataUpdateInfo_<ContainerAllocator>>::other>;
  _data_info_type data_info;

  // setters for named parameter idiom
  Type & set__cmd(
    const uint32_t & _arg)
  {
    this->cmd = _arg;
    return *this;
  }
  Type & set__exec_id(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->exec_id = _arg;
    return *this;
  }
  Type & set__map_info(
    const clean_msgs::msg::MapInfo_<ContainerAllocator> & _arg)
  {
    this->map_info = _arg;
    return *this;
  }
  Type & set__data_info(
    const std::vector<clean_msgs::msg::MapDataUpdateInfo_<ContainerAllocator>, typename ContainerAllocator::template rebind<clean_msgs::msg::MapDataUpdateInfo_<ContainerAllocator>>::other> & _arg)
  {
    this->data_info = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint32_t MAP_START =
    1u;
  static constexpr uint32_t MAP_SAVE =
    2u;
  static constexpr uint32_t MAP_UPDATE =
    3u;
  static constexpr uint32_t MAP_CANCEL =
    4u;
  static constexpr uint32_t MAP_DELETE =
    5u;
  static constexpr uint32_t MAP_EXTEND =
    6u;
  static constexpr uint32_t MAP_LOOP =
    7u;

  // pointer types
  using RawPtr =
    clean_msgs::srv::MapConfig_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const clean_msgs::srv::MapConfig_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<clean_msgs::srv::MapConfig_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<clean_msgs::srv::MapConfig_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::MapConfig_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::MapConfig_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::MapConfig_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::MapConfig_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<clean_msgs::srv::MapConfig_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<clean_msgs::srv::MapConfig_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__clean_msgs__srv__MapConfig_Request
    std::shared_ptr<clean_msgs::srv::MapConfig_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__clean_msgs__srv__MapConfig_Request
    std::shared_ptr<clean_msgs::srv::MapConfig_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const MapConfig_Request_ & other) const
  {
    if (this->cmd != other.cmd) {
      return false;
    }
    if (this->exec_id != other.exec_id) {
      return false;
    }
    if (this->map_info != other.map_info) {
      return false;
    }
    if (this->data_info != other.data_info) {
      return false;
    }
    return true;
  }
  bool operator!=(const MapConfig_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct MapConfig_Request_

// alias to use template instance with default allocator
using MapConfig_Request =
  clean_msgs::srv::MapConfig_Request_<std::allocator<void>>;

// constant definitions
template<typename ContainerAllocator>
constexpr uint32_t MapConfig_Request_<ContainerAllocator>::MAP_START;
template<typename ContainerAllocator>
constexpr uint32_t MapConfig_Request_<ContainerAllocator>::MAP_SAVE;
template<typename ContainerAllocator>
constexpr uint32_t MapConfig_Request_<ContainerAllocator>::MAP_UPDATE;
template<typename ContainerAllocator>
constexpr uint32_t MapConfig_Request_<ContainerAllocator>::MAP_CANCEL;
template<typename ContainerAllocator>
constexpr uint32_t MapConfig_Request_<ContainerAllocator>::MAP_DELETE;
template<typename ContainerAllocator>
constexpr uint32_t MapConfig_Request_<ContainerAllocator>::MAP_EXTEND;
template<typename ContainerAllocator>
constexpr uint32_t MapConfig_Request_<ContainerAllocator>::MAP_LOOP;

}  // namespace srv

}  // namespace clean_msgs


#ifndef _WIN32
# define DEPRECATED__clean_msgs__srv__MapConfig_Response __attribute__((deprecated))
#else
# define DEPRECATED__clean_msgs__srv__MapConfig_Response __declspec(deprecated)
#endif

namespace clean_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct MapConfig_Response_
{
  using Type = MapConfig_Response_<ContainerAllocator>;

  explicit MapConfig_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->result = 0ul;
      this->map_id = "";
    }
  }

  explicit MapConfig_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : map_id(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->result = 0ul;
      this->map_id = "";
    }
  }

  // field types and members
  using _result_type =
    uint32_t;
  _result_type result;
  using _map_id_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _map_id_type map_id;

  // setters for named parameter idiom
  Type & set__result(
    const uint32_t & _arg)
  {
    this->result = _arg;
    return *this;
  }
  Type & set__map_id(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->map_id = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    clean_msgs::srv::MapConfig_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const clean_msgs::srv::MapConfig_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<clean_msgs::srv::MapConfig_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<clean_msgs::srv::MapConfig_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::MapConfig_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::MapConfig_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::MapConfig_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::MapConfig_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<clean_msgs::srv::MapConfig_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<clean_msgs::srv::MapConfig_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__clean_msgs__srv__MapConfig_Response
    std::shared_ptr<clean_msgs::srv::MapConfig_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__clean_msgs__srv__MapConfig_Response
    std::shared_ptr<clean_msgs::srv::MapConfig_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const MapConfig_Response_ & other) const
  {
    if (this->result != other.result) {
      return false;
    }
    if (this->map_id != other.map_id) {
      return false;
    }
    return true;
  }
  bool operator!=(const MapConfig_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct MapConfig_Response_

// alias to use template instance with default allocator
using MapConfig_Response =
  clean_msgs::srv::MapConfig_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace clean_msgs

namespace clean_msgs
{

namespace srv
{

struct MapConfig
{
  using Request = clean_msgs::srv::MapConfig_Request;
  using Response = clean_msgs::srv::MapConfig_Response;
};

}  // namespace srv

}  // namespace clean_msgs

#endif  // CLEAN_MSGS__SRV__DETAIL__MAP_CONFIG__STRUCT_HPP_
