// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from clean_msgs:srv/ManualCleanCtrl.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__MANUAL_CLEAN_CTRL__STRUCT_HPP_
#define CLEAN_MSGS__SRV__DETAIL__MANUAL_CLEAN_CTRL__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__clean_msgs__srv__ManualCleanCtrl_Request __attribute__((deprecated))
#else
# define DEPRECATED__clean_msgs__srv__ManualCleanCtrl_Request __declspec(deprecated)
#endif

namespace clean_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct ManualCleanCtrl_Request_
{
  using Type = ManualCleanCtrl_Request_<ContainerAllocator>;

  explicit ManualCleanCtrl_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->cmd = 0ul;
      this->exec_id = "";
      this->mode_id = "";
      this->post_stop_type = 0;
    }
  }

  explicit ManualCleanCtrl_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : exec_id(_alloc),
    mode_id(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->cmd = 0ul;
      this->exec_id = "";
      this->mode_id = "";
      this->post_stop_type = 0;
    }
  }

  // field types and members
  using _cmd_type =
    uint32_t;
  _cmd_type cmd;
  using _exec_id_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _exec_id_type exec_id;
  using _mode_id_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _mode_id_type mode_id;
  using _post_stop_type_type =
    uint8_t;
  _post_stop_type_type post_stop_type;

  // setters for named parameter idiom
  Type & set__cmd(
    const uint32_t & _arg)
  {
    this->cmd = _arg;
    return *this;
  }
  Type & set__exec_id(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->exec_id = _arg;
    return *this;
  }
  Type & set__mode_id(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->mode_id = _arg;
    return *this;
  }
  Type & set__post_stop_type(
    const uint8_t & _arg)
  {
    this->post_stop_type = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint32_t START =
    1u;
  static constexpr uint32_t CANCEL =
    2u;
  static constexpr uint32_t SWITCH =
    3u;
  static constexpr uint8_t CANCEL_TYPE_POST_NOTHING =
    0u;
  static constexpr uint8_t CANCEL_TYPE_POST_COLLECT =
    1u;

  // pointer types
  using RawPtr =
    clean_msgs::srv::ManualCleanCtrl_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const clean_msgs::srv::ManualCleanCtrl_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<clean_msgs::srv::ManualCleanCtrl_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<clean_msgs::srv::ManualCleanCtrl_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::ManualCleanCtrl_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::ManualCleanCtrl_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::ManualCleanCtrl_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::ManualCleanCtrl_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<clean_msgs::srv::ManualCleanCtrl_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<clean_msgs::srv::ManualCleanCtrl_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__clean_msgs__srv__ManualCleanCtrl_Request
    std::shared_ptr<clean_msgs::srv::ManualCleanCtrl_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__clean_msgs__srv__ManualCleanCtrl_Request
    std::shared_ptr<clean_msgs::srv::ManualCleanCtrl_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ManualCleanCtrl_Request_ & other) const
  {
    if (this->cmd != other.cmd) {
      return false;
    }
    if (this->exec_id != other.exec_id) {
      return false;
    }
    if (this->mode_id != other.mode_id) {
      return false;
    }
    if (this->post_stop_type != other.post_stop_type) {
      return false;
    }
    return true;
  }
  bool operator!=(const ManualCleanCtrl_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ManualCleanCtrl_Request_

// alias to use template instance with default allocator
using ManualCleanCtrl_Request =
  clean_msgs::srv::ManualCleanCtrl_Request_<std::allocator<void>>;

// constant definitions
template<typename ContainerAllocator>
constexpr uint32_t ManualCleanCtrl_Request_<ContainerAllocator>::START;
template<typename ContainerAllocator>
constexpr uint32_t ManualCleanCtrl_Request_<ContainerAllocator>::CANCEL;
template<typename ContainerAllocator>
constexpr uint32_t ManualCleanCtrl_Request_<ContainerAllocator>::SWITCH;
template<typename ContainerAllocator>
constexpr uint8_t ManualCleanCtrl_Request_<ContainerAllocator>::CANCEL_TYPE_POST_NOTHING;
template<typename ContainerAllocator>
constexpr uint8_t ManualCleanCtrl_Request_<ContainerAllocator>::CANCEL_TYPE_POST_COLLECT;

}  // namespace srv

}  // namespace clean_msgs


#ifndef _WIN32
# define DEPRECATED__clean_msgs__srv__ManualCleanCtrl_Response __attribute__((deprecated))
#else
# define DEPRECATED__clean_msgs__srv__ManualCleanCtrl_Response __declspec(deprecated)
#endif

namespace clean_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct ManualCleanCtrl_Response_
{
  using Type = ManualCleanCtrl_Response_<ContainerAllocator>;

  explicit ManualCleanCtrl_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->result = 0ul;
      this->exec_id = "";
    }
  }

  explicit ManualCleanCtrl_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : exec_id(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->result = 0ul;
      this->exec_id = "";
    }
  }

  // field types and members
  using _result_type =
    uint32_t;
  _result_type result;
  using _exec_id_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _exec_id_type exec_id;

  // setters for named parameter idiom
  Type & set__result(
    const uint32_t & _arg)
  {
    this->result = _arg;
    return *this;
  }
  Type & set__exec_id(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->exec_id = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    clean_msgs::srv::ManualCleanCtrl_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const clean_msgs::srv::ManualCleanCtrl_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<clean_msgs::srv::ManualCleanCtrl_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<clean_msgs::srv::ManualCleanCtrl_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::ManualCleanCtrl_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::ManualCleanCtrl_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::ManualCleanCtrl_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::ManualCleanCtrl_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<clean_msgs::srv::ManualCleanCtrl_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<clean_msgs::srv::ManualCleanCtrl_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__clean_msgs__srv__ManualCleanCtrl_Response
    std::shared_ptr<clean_msgs::srv::ManualCleanCtrl_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__clean_msgs__srv__ManualCleanCtrl_Response
    std::shared_ptr<clean_msgs::srv::ManualCleanCtrl_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ManualCleanCtrl_Response_ & other) const
  {
    if (this->result != other.result) {
      return false;
    }
    if (this->exec_id != other.exec_id) {
      return false;
    }
    return true;
  }
  bool operator!=(const ManualCleanCtrl_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ManualCleanCtrl_Response_

// alias to use template instance with default allocator
using ManualCleanCtrl_Response =
  clean_msgs::srv::ManualCleanCtrl_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace clean_msgs

namespace clean_msgs
{

namespace srv
{

struct ManualCleanCtrl
{
  using Request = clean_msgs::srv::ManualCleanCtrl_Request;
  using Response = clean_msgs::srv::ManualCleanCtrl_Response;
};

}  // namespace srv

}  // namespace clean_msgs

#endif  // CLEAN_MSGS__SRV__DETAIL__MANUAL_CLEAN_CTRL__STRUCT_HPP_
