// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from clean_msgs:srv/GetCurCleanMode.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__GET_CUR_CLEAN_MODE__BUILDER_HPP_
#define CLEAN_MSGS__SRV__DETAIL__GET_CUR_CLEAN_MODE__BUILDER_HPP_

#include "clean_msgs/srv/detail/get_cur_clean_mode__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_GetCurCleanMode_Request_cmd
{
public:
  Init_GetCurCleanMode_Request_cmd()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::clean_msgs::srv::GetCurCleanMode_Request cmd(::clean_msgs::srv::GetCurCleanMode_Request::_cmd_type arg)
  {
    msg_.cmd = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::GetCurCleanMode_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::GetCurCleanMode_Request>()
{
  return clean_msgs::srv::builder::Init_GetCurCleanMode_Request_cmd();
}

}  // namespace clean_msgs


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_GetCurCleanMode_Response_mode_name
{
public:
  explicit Init_GetCurCleanMode_Response_mode_name(::clean_msgs::srv::GetCurCleanMode_Response & msg)
  : msg_(msg)
  {}
  ::clean_msgs::srv::GetCurCleanMode_Response mode_name(::clean_msgs::srv::GetCurCleanMode_Response::_mode_name_type arg)
  {
    msg_.mode_name = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::GetCurCleanMode_Response msg_;
};

class Init_GetCurCleanMode_Response_mode_id
{
public:
  explicit Init_GetCurCleanMode_Response_mode_id(::clean_msgs::srv::GetCurCleanMode_Response & msg)
  : msg_(msg)
  {}
  Init_GetCurCleanMode_Response_mode_name mode_id(::clean_msgs::srv::GetCurCleanMode_Response::_mode_id_type arg)
  {
    msg_.mode_id = std::move(arg);
    return Init_GetCurCleanMode_Response_mode_name(msg_);
  }

private:
  ::clean_msgs::srv::GetCurCleanMode_Response msg_;
};

class Init_GetCurCleanMode_Response_result
{
public:
  Init_GetCurCleanMode_Response_result()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_GetCurCleanMode_Response_mode_id result(::clean_msgs::srv::GetCurCleanMode_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return Init_GetCurCleanMode_Response_mode_id(msg_);
  }

private:
  ::clean_msgs::srv::GetCurCleanMode_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::GetCurCleanMode_Response>()
{
  return clean_msgs::srv::builder::Init_GetCurCleanMode_Response_result();
}

}  // namespace clean_msgs

#endif  // CLEAN_MSGS__SRV__DETAIL__GET_CUR_CLEAN_MODE__BUILDER_HPP_
