// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from clean_msgs:srv/TaskReportGet.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__TASK_REPORT_GET__BUILDER_HPP_
#define CLEAN_MSGS__SRV__DETAIL__TASK_REPORT_GET__BUILDER_HPP_

#include "clean_msgs/srv/detail/task_report_get__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_TaskReportGet_Request_task_exe_id
{
public:
  Init_TaskReportGet_Request_task_exe_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::clean_msgs::srv::TaskReportGet_Request task_exe_id(::clean_msgs::srv::TaskReportGet_Request::_task_exe_id_type arg)
  {
    msg_.task_exe_id = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::TaskReportGet_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::TaskReportGet_Request>()
{
  return clean_msgs::srv::builder::Init_TaskReportGet_Request_task_exe_id();
}

}  // namespace clean_msgs


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_TaskReportGet_Response_cleaning_efficiency
{
public:
  explicit Init_TaskReportGet_Response_cleaning_efficiency(::clean_msgs::srv::TaskReportGet_Response & msg)
  : msg_(msg)
  {}
  ::clean_msgs::srv::TaskReportGet_Response cleaning_efficiency(::clean_msgs::srv::TaskReportGet_Response::_cleaning_efficiency_type arg)
  {
    msg_.cleaning_efficiency = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::TaskReportGet_Response msg_;
};

class Init_TaskReportGet_Response_finish_per
{
public:
  explicit Init_TaskReportGet_Response_finish_per(::clean_msgs::srv::TaskReportGet_Response & msg)
  : msg_(msg)
  {}
  Init_TaskReportGet_Response_cleaning_efficiency finish_per(::clean_msgs::srv::TaskReportGet_Response::_finish_per_type arg)
  {
    msg_.finish_per = std::move(arg);
    return Init_TaskReportGet_Response_cleaning_efficiency(msg_);
  }

private:
  ::clean_msgs::srv::TaskReportGet_Response msg_;
};

class Init_TaskReportGet_Response_actual_area
{
public:
  explicit Init_TaskReportGet_Response_actual_area(::clean_msgs::srv::TaskReportGet_Response & msg)
  : msg_(msg)
  {}
  Init_TaskReportGet_Response_finish_per actual_area(::clean_msgs::srv::TaskReportGet_Response::_actual_area_type arg)
  {
    msg_.actual_area = std::move(arg);
    return Init_TaskReportGet_Response_finish_per(msg_);
  }

private:
  ::clean_msgs::srv::TaskReportGet_Response msg_;
};

class Init_TaskReportGet_Response_spent_battery
{
public:
  explicit Init_TaskReportGet_Response_spent_battery(::clean_msgs::srv::TaskReportGet_Response & msg)
  : msg_(msg)
  {}
  Init_TaskReportGet_Response_actual_area spent_battery(::clean_msgs::srv::TaskReportGet_Response::_spent_battery_type arg)
  {
    msg_.spent_battery = std::move(arg);
    return Init_TaskReportGet_Response_actual_area(msg_);
  }

private:
  ::clean_msgs::srv::TaskReportGet_Response msg_;
};

class Init_TaskReportGet_Response_spent_water
{
public:
  explicit Init_TaskReportGet_Response_spent_water(::clean_msgs::srv::TaskReportGet_Response & msg)
  : msg_(msg)
  {}
  Init_TaskReportGet_Response_spent_battery spent_water(::clean_msgs::srv::TaskReportGet_Response::_spent_water_type arg)
  {
    msg_.spent_water = std::move(arg);
    return Init_TaskReportGet_Response_spent_battery(msg_);
  }

private:
  ::clean_msgs::srv::TaskReportGet_Response msg_;
};

class Init_TaskReportGet_Response_spent_time
{
public:
  explicit Init_TaskReportGet_Response_spent_time(::clean_msgs::srv::TaskReportGet_Response & msg)
  : msg_(msg)
  {}
  Init_TaskReportGet_Response_spent_water spent_time(::clean_msgs::srv::TaskReportGet_Response::_spent_time_type arg)
  {
    msg_.spent_time = std::move(arg);
    return Init_TaskReportGet_Response_spent_water(msg_);
  }

private:
  ::clean_msgs::srv::TaskReportGet_Response msg_;
};

class Init_TaskReportGet_Response_supply_times
{
public:
  explicit Init_TaskReportGet_Response_supply_times(::clean_msgs::srv::TaskReportGet_Response & msg)
  : msg_(msg)
  {}
  Init_TaskReportGet_Response_spent_time supply_times(::clean_msgs::srv::TaskReportGet_Response::_supply_times_type arg)
  {
    msg_.supply_times = std::move(arg);
    return Init_TaskReportGet_Response_spent_time(msg_);
  }

private:
  ::clean_msgs::srv::TaskReportGet_Response msg_;
};

class Init_TaskReportGet_Response_finished_type
{
public:
  explicit Init_TaskReportGet_Response_finished_type(::clean_msgs::srv::TaskReportGet_Response & msg)
  : msg_(msg)
  {}
  Init_TaskReportGet_Response_supply_times finished_type(::clean_msgs::srv::TaskReportGet_Response::_finished_type_type arg)
  {
    msg_.finished_type = std::move(arg);
    return Init_TaskReportGet_Response_supply_times(msg_);
  }

private:
  ::clean_msgs::srv::TaskReportGet_Response msg_;
};

class Init_TaskReportGet_Response_end_utc_time
{
public:
  explicit Init_TaskReportGet_Response_end_utc_time(::clean_msgs::srv::TaskReportGet_Response & msg)
  : msg_(msg)
  {}
  Init_TaskReportGet_Response_finished_type end_utc_time(::clean_msgs::srv::TaskReportGet_Response::_end_utc_time_type arg)
  {
    msg_.end_utc_time = std::move(arg);
    return Init_TaskReportGet_Response_finished_type(msg_);
  }

private:
  ::clean_msgs::srv::TaskReportGet_Response msg_;
};

class Init_TaskReportGet_Response_start_utc_time
{
public:
  explicit Init_TaskReportGet_Response_start_utc_time(::clean_msgs::srv::TaskReportGet_Response & msg)
  : msg_(msg)
  {}
  Init_TaskReportGet_Response_end_utc_time start_utc_time(::clean_msgs::srv::TaskReportGet_Response::_start_utc_time_type arg)
  {
    msg_.start_utc_time = std::move(arg);
    return Init_TaskReportGet_Response_end_utc_time(msg_);
  }

private:
  ::clean_msgs::srv::TaskReportGet_Response msg_;
};

class Init_TaskReportGet_Response_loop
{
public:
  explicit Init_TaskReportGet_Response_loop(::clean_msgs::srv::TaskReportGet_Response & msg)
  : msg_(msg)
  {}
  Init_TaskReportGet_Response_start_utc_time loop(::clean_msgs::srv::TaskReportGet_Response::_loop_type arg)
  {
    msg_.loop = std::move(arg);
    return Init_TaskReportGet_Response_start_utc_time(msg_);
  }

private:
  ::clean_msgs::srv::TaskReportGet_Response msg_;
};

class Init_TaskReportGet_Response_actual_loop
{
public:
  explicit Init_TaskReportGet_Response_actual_loop(::clean_msgs::srv::TaskReportGet_Response & msg)
  : msg_(msg)
  {}
  Init_TaskReportGet_Response_loop actual_loop(::clean_msgs::srv::TaskReportGet_Response::_actual_loop_type arg)
  {
    msg_.actual_loop = std::move(arg);
    return Init_TaskReportGet_Response_loop(msg_);
  }

private:
  ::clean_msgs::srv::TaskReportGet_Response msg_;
};

class Init_TaskReportGet_Response_cleaning_mode_name
{
public:
  explicit Init_TaskReportGet_Response_cleaning_mode_name(::clean_msgs::srv::TaskReportGet_Response & msg)
  : msg_(msg)
  {}
  Init_TaskReportGet_Response_actual_loop cleaning_mode_name(::clean_msgs::srv::TaskReportGet_Response::_cleaning_mode_name_type arg)
  {
    msg_.cleaning_mode_name = std::move(arg);
    return Init_TaskReportGet_Response_actual_loop(msg_);
  }

private:
  ::clean_msgs::srv::TaskReportGet_Response msg_;
};

class Init_TaskReportGet_Response_cleaning_mode_id
{
public:
  explicit Init_TaskReportGet_Response_cleaning_mode_id(::clean_msgs::srv::TaskReportGet_Response & msg)
  : msg_(msg)
  {}
  Init_TaskReportGet_Response_cleaning_mode_name cleaning_mode_id(::clean_msgs::srv::TaskReportGet_Response::_cleaning_mode_id_type arg)
  {
    msg_.cleaning_mode_id = std::move(arg);
    return Init_TaskReportGet_Response_cleaning_mode_name(msg_);
  }

private:
  ::clean_msgs::srv::TaskReportGet_Response msg_;
};

class Init_TaskReportGet_Response_task_name
{
public:
  explicit Init_TaskReportGet_Response_task_name(::clean_msgs::srv::TaskReportGet_Response & msg)
  : msg_(msg)
  {}
  Init_TaskReportGet_Response_cleaning_mode_id task_name(::clean_msgs::srv::TaskReportGet_Response::_task_name_type arg)
  {
    msg_.task_name = std::move(arg);
    return Init_TaskReportGet_Response_cleaning_mode_id(msg_);
  }

private:
  ::clean_msgs::srv::TaskReportGet_Response msg_;
};

class Init_TaskReportGet_Response_task_exe_id
{
public:
  explicit Init_TaskReportGet_Response_task_exe_id(::clean_msgs::srv::TaskReportGet_Response & msg)
  : msg_(msg)
  {}
  Init_TaskReportGet_Response_task_name task_exe_id(::clean_msgs::srv::TaskReportGet_Response::_task_exe_id_type arg)
  {
    msg_.task_exe_id = std::move(arg);
    return Init_TaskReportGet_Response_task_name(msg_);
  }

private:
  ::clean_msgs::srv::TaskReportGet_Response msg_;
};

class Init_TaskReportGet_Response_result
{
public:
  Init_TaskReportGet_Response_result()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_TaskReportGet_Response_task_exe_id result(::clean_msgs::srv::TaskReportGet_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return Init_TaskReportGet_Response_task_exe_id(msg_);
  }

private:
  ::clean_msgs::srv::TaskReportGet_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::TaskReportGet_Response>()
{
  return clean_msgs::srv::builder::Init_TaskReportGet_Response_result();
}

}  // namespace clean_msgs

#endif  // CLEAN_MSGS__SRV__DETAIL__TASK_REPORT_GET__BUILDER_HPP_
