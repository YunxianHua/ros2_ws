// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from clean_msgs:srv/TaskReportGet.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__TASK_REPORT_GET__STRUCT_HPP_
#define CLEAN_MSGS__SRV__DETAIL__TASK_REPORT_GET__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__clean_msgs__srv__TaskReportGet_Request __attribute__((deprecated))
#else
# define DEPRECATED__clean_msgs__srv__TaskReportGet_Request __declspec(deprecated)
#endif

namespace clean_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct TaskReportGet_Request_
{
  using Type = TaskReportGet_Request_<ContainerAllocator>;

  explicit TaskReportGet_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->task_exe_id = "";
    }
  }

  explicit TaskReportGet_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : task_exe_id(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->task_exe_id = "";
    }
  }

  // field types and members
  using _task_exe_id_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _task_exe_id_type task_exe_id;

  // setters for named parameter idiom
  Type & set__task_exe_id(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->task_exe_id = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint32_t FINISHED_TYPE_UNKNOWN =
    0u;
  static constexpr uint32_t FINISHED_TYPE_NORMAL =
    1u;
  static constexpr uint32_t FINISHED_TYPE_EXCEPTION =
    2u;
  static constexpr uint32_t FINISHED_TYPE_MANUAL =
    3u;
  static constexpr uint32_t FINISHED_TYPE_CONTIUNE_ABANDON =
    4u;

  // pointer types
  using RawPtr =
    clean_msgs::srv::TaskReportGet_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const clean_msgs::srv::TaskReportGet_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<clean_msgs::srv::TaskReportGet_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<clean_msgs::srv::TaskReportGet_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::TaskReportGet_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::TaskReportGet_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::TaskReportGet_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::TaskReportGet_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<clean_msgs::srv::TaskReportGet_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<clean_msgs::srv::TaskReportGet_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__clean_msgs__srv__TaskReportGet_Request
    std::shared_ptr<clean_msgs::srv::TaskReportGet_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__clean_msgs__srv__TaskReportGet_Request
    std::shared_ptr<clean_msgs::srv::TaskReportGet_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const TaskReportGet_Request_ & other) const
  {
    if (this->task_exe_id != other.task_exe_id) {
      return false;
    }
    return true;
  }
  bool operator!=(const TaskReportGet_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct TaskReportGet_Request_

// alias to use template instance with default allocator
using TaskReportGet_Request =
  clean_msgs::srv::TaskReportGet_Request_<std::allocator<void>>;

// constant definitions
template<typename ContainerAllocator>
constexpr uint32_t TaskReportGet_Request_<ContainerAllocator>::FINISHED_TYPE_UNKNOWN;
template<typename ContainerAllocator>
constexpr uint32_t TaskReportGet_Request_<ContainerAllocator>::FINISHED_TYPE_NORMAL;
template<typename ContainerAllocator>
constexpr uint32_t TaskReportGet_Request_<ContainerAllocator>::FINISHED_TYPE_EXCEPTION;
template<typename ContainerAllocator>
constexpr uint32_t TaskReportGet_Request_<ContainerAllocator>::FINISHED_TYPE_MANUAL;
template<typename ContainerAllocator>
constexpr uint32_t TaskReportGet_Request_<ContainerAllocator>::FINISHED_TYPE_CONTIUNE_ABANDON;

}  // namespace srv

}  // namespace clean_msgs


#ifndef _WIN32
# define DEPRECATED__clean_msgs__srv__TaskReportGet_Response __attribute__((deprecated))
#else
# define DEPRECATED__clean_msgs__srv__TaskReportGet_Response __declspec(deprecated)
#endif

namespace clean_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct TaskReportGet_Response_
{
  using Type = TaskReportGet_Response_<ContainerAllocator>;

  explicit TaskReportGet_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->result = 0ul;
      this->task_exe_id = "";
      this->task_name = "";
      this->cleaning_mode_id = "";
      this->cleaning_mode_name = "";
      this->actual_loop = 0ul;
      this->loop = 0ul;
      this->start_utc_time = 0ul;
      this->end_utc_time = 0ul;
      this->finished_type = 0ul;
      this->supply_times = 0ul;
      this->spent_time = 0ul;
      this->spent_water = 0.0f;
      this->spent_battery = 0.0f;
      this->actual_area = 0ul;
      this->finish_per = 0.0f;
      this->cleaning_efficiency = 0ul;
    }
  }

  explicit TaskReportGet_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : task_exe_id(_alloc),
    task_name(_alloc),
    cleaning_mode_id(_alloc),
    cleaning_mode_name(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->result = 0ul;
      this->task_exe_id = "";
      this->task_name = "";
      this->cleaning_mode_id = "";
      this->cleaning_mode_name = "";
      this->actual_loop = 0ul;
      this->loop = 0ul;
      this->start_utc_time = 0ul;
      this->end_utc_time = 0ul;
      this->finished_type = 0ul;
      this->supply_times = 0ul;
      this->spent_time = 0ul;
      this->spent_water = 0.0f;
      this->spent_battery = 0.0f;
      this->actual_area = 0ul;
      this->finish_per = 0.0f;
      this->cleaning_efficiency = 0ul;
    }
  }

  // field types and members
  using _result_type =
    uint32_t;
  _result_type result;
  using _task_exe_id_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _task_exe_id_type task_exe_id;
  using _task_name_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _task_name_type task_name;
  using _cleaning_mode_id_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _cleaning_mode_id_type cleaning_mode_id;
  using _cleaning_mode_name_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _cleaning_mode_name_type cleaning_mode_name;
  using _actual_loop_type =
    uint32_t;
  _actual_loop_type actual_loop;
  using _loop_type =
    uint32_t;
  _loop_type loop;
  using _start_utc_time_type =
    uint32_t;
  _start_utc_time_type start_utc_time;
  using _end_utc_time_type =
    uint32_t;
  _end_utc_time_type end_utc_time;
  using _finished_type_type =
    uint32_t;
  _finished_type_type finished_type;
  using _supply_times_type =
    uint32_t;
  _supply_times_type supply_times;
  using _spent_time_type =
    uint32_t;
  _spent_time_type spent_time;
  using _spent_water_type =
    float;
  _spent_water_type spent_water;
  using _spent_battery_type =
    float;
  _spent_battery_type spent_battery;
  using _actual_area_type =
    uint32_t;
  _actual_area_type actual_area;
  using _finish_per_type =
    float;
  _finish_per_type finish_per;
  using _cleaning_efficiency_type =
    uint32_t;
  _cleaning_efficiency_type cleaning_efficiency;

  // setters for named parameter idiom
  Type & set__result(
    const uint32_t & _arg)
  {
    this->result = _arg;
    return *this;
  }
  Type & set__task_exe_id(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->task_exe_id = _arg;
    return *this;
  }
  Type & set__task_name(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->task_name = _arg;
    return *this;
  }
  Type & set__cleaning_mode_id(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->cleaning_mode_id = _arg;
    return *this;
  }
  Type & set__cleaning_mode_name(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->cleaning_mode_name = _arg;
    return *this;
  }
  Type & set__actual_loop(
    const uint32_t & _arg)
  {
    this->actual_loop = _arg;
    return *this;
  }
  Type & set__loop(
    const uint32_t & _arg)
  {
    this->loop = _arg;
    return *this;
  }
  Type & set__start_utc_time(
    const uint32_t & _arg)
  {
    this->start_utc_time = _arg;
    return *this;
  }
  Type & set__end_utc_time(
    const uint32_t & _arg)
  {
    this->end_utc_time = _arg;
    return *this;
  }
  Type & set__finished_type(
    const uint32_t & _arg)
  {
    this->finished_type = _arg;
    return *this;
  }
  Type & set__supply_times(
    const uint32_t & _arg)
  {
    this->supply_times = _arg;
    return *this;
  }
  Type & set__spent_time(
    const uint32_t & _arg)
  {
    this->spent_time = _arg;
    return *this;
  }
  Type & set__spent_water(
    const float & _arg)
  {
    this->spent_water = _arg;
    return *this;
  }
  Type & set__spent_battery(
    const float & _arg)
  {
    this->spent_battery = _arg;
    return *this;
  }
  Type & set__actual_area(
    const uint32_t & _arg)
  {
    this->actual_area = _arg;
    return *this;
  }
  Type & set__finish_per(
    const float & _arg)
  {
    this->finish_per = _arg;
    return *this;
  }
  Type & set__cleaning_efficiency(
    const uint32_t & _arg)
  {
    this->cleaning_efficiency = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    clean_msgs::srv::TaskReportGet_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const clean_msgs::srv::TaskReportGet_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<clean_msgs::srv::TaskReportGet_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<clean_msgs::srv::TaskReportGet_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::TaskReportGet_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::TaskReportGet_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::TaskReportGet_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::TaskReportGet_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<clean_msgs::srv::TaskReportGet_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<clean_msgs::srv::TaskReportGet_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__clean_msgs__srv__TaskReportGet_Response
    std::shared_ptr<clean_msgs::srv::TaskReportGet_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__clean_msgs__srv__TaskReportGet_Response
    std::shared_ptr<clean_msgs::srv::TaskReportGet_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const TaskReportGet_Response_ & other) const
  {
    if (this->result != other.result) {
      return false;
    }
    if (this->task_exe_id != other.task_exe_id) {
      return false;
    }
    if (this->task_name != other.task_name) {
      return false;
    }
    if (this->cleaning_mode_id != other.cleaning_mode_id) {
      return false;
    }
    if (this->cleaning_mode_name != other.cleaning_mode_name) {
      return false;
    }
    if (this->actual_loop != other.actual_loop) {
      return false;
    }
    if (this->loop != other.loop) {
      return false;
    }
    if (this->start_utc_time != other.start_utc_time) {
      return false;
    }
    if (this->end_utc_time != other.end_utc_time) {
      return false;
    }
    if (this->finished_type != other.finished_type) {
      return false;
    }
    if (this->supply_times != other.supply_times) {
      return false;
    }
    if (this->spent_time != other.spent_time) {
      return false;
    }
    if (this->spent_water != other.spent_water) {
      return false;
    }
    if (this->spent_battery != other.spent_battery) {
      return false;
    }
    if (this->actual_area != other.actual_area) {
      return false;
    }
    if (this->finish_per != other.finish_per) {
      return false;
    }
    if (this->cleaning_efficiency != other.cleaning_efficiency) {
      return false;
    }
    return true;
  }
  bool operator!=(const TaskReportGet_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct TaskReportGet_Response_

// alias to use template instance with default allocator
using TaskReportGet_Response =
  clean_msgs::srv::TaskReportGet_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace clean_msgs

namespace clean_msgs
{

namespace srv
{

struct TaskReportGet
{
  using Request = clean_msgs::srv::TaskReportGet_Request;
  using Response = clean_msgs::srv::TaskReportGet_Response;
};

}  // namespace srv

}  // namespace clean_msgs

#endif  // CLEAN_MSGS__SRV__DETAIL__TASK_REPORT_GET__STRUCT_HPP_
