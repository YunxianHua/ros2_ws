// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from clean_msgs:srv/TaskGet.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__TASK_GET__BUILDER_HPP_
#define CLEAN_MSGS__SRV__DETAIL__TASK_GET__BUILDER_HPP_

#include "clean_msgs/srv/detail/task_get__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_TaskGet_Request_task_id
{
public:
  explicit Init_TaskGet_Request_task_id(::clean_msgs::srv::TaskGet_Request & msg)
  : msg_(msg)
  {}
  ::clean_msgs::srv::TaskGet_Request task_id(::clean_msgs::srv::TaskGet_Request::_task_id_type arg)
  {
    msg_.task_id = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::TaskGet_Request msg_;
};

class Init_TaskGet_Request_type
{
public:
  Init_TaskGet_Request_type()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_TaskGet_Request_task_id type(::clean_msgs::srv::TaskGet_Request::_type_type arg)
  {
    msg_.type = std::move(arg);
    return Init_TaskGet_Request_task_id(msg_);
  }

private:
  ::clean_msgs::srv::TaskGet_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::TaskGet_Request>()
{
  return clean_msgs::srv::builder::Init_TaskGet_Request_type();
}

}  // namespace clean_msgs


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_TaskGet_Response_task_suspend_time
{
public:
  explicit Init_TaskGet_Response_task_suspend_time(::clean_msgs::srv::TaskGet_Response & msg)
  : msg_(msg)
  {}
  ::clean_msgs::srv::TaskGet_Response task_suspend_time(::clean_msgs::srv::TaskGet_Response::_task_suspend_time_type arg)
  {
    msg_.task_suspend_time = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::TaskGet_Response msg_;
};

class Init_TaskGet_Response_task_start_time
{
public:
  explicit Init_TaskGet_Response_task_start_time(::clean_msgs::srv::TaskGet_Response & msg)
  : msg_(msg)
  {}
  Init_TaskGet_Response_task_suspend_time task_start_time(::clean_msgs::srv::TaskGet_Response::_task_start_time_type arg)
  {
    msg_.task_start_time = std::move(arg);
    return Init_TaskGet_Response_task_suspend_time(msg_);
  }

private:
  ::clean_msgs::srv::TaskGet_Response msg_;
};

class Init_TaskGet_Response_cur_loop_count
{
public:
  explicit Init_TaskGet_Response_cur_loop_count(::clean_msgs::srv::TaskGet_Response & msg)
  : msg_(msg)
  {}
  Init_TaskGet_Response_task_start_time cur_loop_count(::clean_msgs::srv::TaskGet_Response::_cur_loop_count_type arg)
  {
    msg_.cur_loop_count = std::move(arg);
    return Init_TaskGet_Response_task_start_time(msg_);
  }

private:
  ::clean_msgs::srv::TaskGet_Response msg_;
};

class Init_TaskGet_Response_all_loop_count
{
public:
  explicit Init_TaskGet_Response_all_loop_count(::clean_msgs::srv::TaskGet_Response & msg)
  : msg_(msg)
  {}
  Init_TaskGet_Response_cur_loop_count all_loop_count(::clean_msgs::srv::TaskGet_Response::_all_loop_count_type arg)
  {
    msg_.all_loop_count = std::move(arg);
    return Init_TaskGet_Response_cur_loop_count(msg_);
  }

private:
  ::clean_msgs::srv::TaskGet_Response msg_;
};

class Init_TaskGet_Response_task_cleaning_mode_name
{
public:
  explicit Init_TaskGet_Response_task_cleaning_mode_name(::clean_msgs::srv::TaskGet_Response & msg)
  : msg_(msg)
  {}
  Init_TaskGet_Response_all_loop_count task_cleaning_mode_name(::clean_msgs::srv::TaskGet_Response::_task_cleaning_mode_name_type arg)
  {
    msg_.task_cleaning_mode_name = std::move(arg);
    return Init_TaskGet_Response_all_loop_count(msg_);
  }

private:
  ::clean_msgs::srv::TaskGet_Response msg_;
};

class Init_TaskGet_Response_task_cleaning_mode_id
{
public:
  explicit Init_TaskGet_Response_task_cleaning_mode_id(::clean_msgs::srv::TaskGet_Response & msg)
  : msg_(msg)
  {}
  Init_TaskGet_Response_task_cleaning_mode_name task_cleaning_mode_id(::clean_msgs::srv::TaskGet_Response::_task_cleaning_mode_id_type arg)
  {
    msg_.task_cleaning_mode_id = std::move(arg);
    return Init_TaskGet_Response_task_cleaning_mode_name(msg_);
  }

private:
  ::clean_msgs::srv::TaskGet_Response msg_;
};

class Init_TaskGet_Response_subtasks
{
public:
  explicit Init_TaskGet_Response_subtasks(::clean_msgs::srv::TaskGet_Response & msg)
  : msg_(msg)
  {}
  Init_TaskGet_Response_task_cleaning_mode_id subtasks(::clean_msgs::srv::TaskGet_Response::_subtasks_type arg)
  {
    msg_.subtasks = std::move(arg);
    return Init_TaskGet_Response_task_cleaning_mode_id(msg_);
  }

private:
  ::clean_msgs::srv::TaskGet_Response msg_;
};

class Init_TaskGet_Response_name
{
public:
  explicit Init_TaskGet_Response_name(::clean_msgs::srv::TaskGet_Response & msg)
  : msg_(msg)
  {}
  Init_TaskGet_Response_subtasks name(::clean_msgs::srv::TaskGet_Response::_name_type arg)
  {
    msg_.name = std::move(arg);
    return Init_TaskGet_Response_subtasks(msg_);
  }

private:
  ::clean_msgs::srv::TaskGet_Response msg_;
};

class Init_TaskGet_Response_id
{
public:
  explicit Init_TaskGet_Response_id(::clean_msgs::srv::TaskGet_Response & msg)
  : msg_(msg)
  {}
  Init_TaskGet_Response_name id(::clean_msgs::srv::TaskGet_Response::_id_type arg)
  {
    msg_.id = std::move(arg);
    return Init_TaskGet_Response_name(msg_);
  }

private:
  ::clean_msgs::srv::TaskGet_Response msg_;
};

class Init_TaskGet_Response_result
{
public:
  Init_TaskGet_Response_result()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_TaskGet_Response_id result(::clean_msgs::srv::TaskGet_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return Init_TaskGet_Response_id(msg_);
  }

private:
  ::clean_msgs::srv::TaskGet_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::TaskGet_Response>()
{
  return clean_msgs::srv::builder::Init_TaskGet_Response_result();
}

}  // namespace clean_msgs

#endif  // CLEAN_MSGS__SRV__DETAIL__TASK_GET__BUILDER_HPP_
