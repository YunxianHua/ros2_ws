// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from clean_msgs:srv/PointCreate.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__POINT_CREATE__BUILDER_HPP_
#define CLEAN_MSGS__SRV__DETAIL__POINT_CREATE__BUILDER_HPP_

#include "clean_msgs/srv/detail/point_create__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_PointCreate_Request_point_yaw
{
public:
  explicit Init_PointCreate_Request_point_yaw(::clean_msgs::srv::PointCreate_Request & msg)
  : msg_(msg)
  {}
  ::clean_msgs::srv::PointCreate_Request point_yaw(::clean_msgs::srv::PointCreate_Request::_point_yaw_type arg)
  {
    msg_.point_yaw = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::PointCreate_Request msg_;
};

class Init_PointCreate_Request_point_y
{
public:
  explicit Init_PointCreate_Request_point_y(::clean_msgs::srv::PointCreate_Request & msg)
  : msg_(msg)
  {}
  Init_PointCreate_Request_point_yaw point_y(::clean_msgs::srv::PointCreate_Request::_point_y_type arg)
  {
    msg_.point_y = std::move(arg);
    return Init_PointCreate_Request_point_yaw(msg_);
  }

private:
  ::clean_msgs::srv::PointCreate_Request msg_;
};

class Init_PointCreate_Request_point_x
{
public:
  explicit Init_PointCreate_Request_point_x(::clean_msgs::srv::PointCreate_Request & msg)
  : msg_(msg)
  {}
  Init_PointCreate_Request_point_y point_x(::clean_msgs::srv::PointCreate_Request::_point_x_type arg)
  {
    msg_.point_x = std::move(arg);
    return Init_PointCreate_Request_point_y(msg_);
  }

private:
  ::clean_msgs::srv::PointCreate_Request msg_;
};

class Init_PointCreate_Request_name
{
public:
  explicit Init_PointCreate_Request_name(::clean_msgs::srv::PointCreate_Request & msg)
  : msg_(msg)
  {}
  Init_PointCreate_Request_point_x name(::clean_msgs::srv::PointCreate_Request::_name_type arg)
  {
    msg_.name = std::move(arg);
    return Init_PointCreate_Request_point_x(msg_);
  }

private:
  ::clean_msgs::srv::PointCreate_Request msg_;
};

class Init_PointCreate_Request_create_type
{
public:
  explicit Init_PointCreate_Request_create_type(::clean_msgs::srv::PointCreate_Request & msg)
  : msg_(msg)
  {}
  Init_PointCreate_Request_name create_type(::clean_msgs::srv::PointCreate_Request::_create_type_type arg)
  {
    msg_.create_type = std::move(arg);
    return Init_PointCreate_Request_name(msg_);
  }

private:
  ::clean_msgs::srv::PointCreate_Request msg_;
};

class Init_PointCreate_Request_type
{
public:
  explicit Init_PointCreate_Request_type(::clean_msgs::srv::PointCreate_Request & msg)
  : msg_(msg)
  {}
  Init_PointCreate_Request_create_type type(::clean_msgs::srv::PointCreate_Request::_type_type arg)
  {
    msg_.type = std::move(arg);
    return Init_PointCreate_Request_create_type(msg_);
  }

private:
  ::clean_msgs::srv::PointCreate_Request msg_;
};

class Init_PointCreate_Request_map_id
{
public:
  Init_PointCreate_Request_map_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_PointCreate_Request_type map_id(::clean_msgs::srv::PointCreate_Request::_map_id_type arg)
  {
    msg_.map_id = std::move(arg);
    return Init_PointCreate_Request_type(msg_);
  }

private:
  ::clean_msgs::srv::PointCreate_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::PointCreate_Request>()
{
  return clean_msgs::srv::builder::Init_PointCreate_Request_map_id();
}

}  // namespace clean_msgs


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_PointCreate_Response_point_id
{
public:
  explicit Init_PointCreate_Response_point_id(::clean_msgs::srv::PointCreate_Response & msg)
  : msg_(msg)
  {}
  ::clean_msgs::srv::PointCreate_Response point_id(::clean_msgs::srv::PointCreate_Response::_point_id_type arg)
  {
    msg_.point_id = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::PointCreate_Response msg_;
};

class Init_PointCreate_Response_result
{
public:
  Init_PointCreate_Response_result()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_PointCreate_Response_point_id result(::clean_msgs::srv::PointCreate_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return Init_PointCreate_Response_point_id(msg_);
  }

private:
  ::clean_msgs::srv::PointCreate_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::PointCreate_Response>()
{
  return clean_msgs::srv::builder::Init_PointCreate_Response_result();
}

}  // namespace clean_msgs

#endif  // CLEAN_MSGS__SRV__DETAIL__POINT_CREATE__BUILDER_HPP_
