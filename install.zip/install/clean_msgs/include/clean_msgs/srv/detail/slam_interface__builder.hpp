// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from clean_msgs:srv/SlamInterface.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__SLAM_INTERFACE__BUILDER_HPP_
#define CLEAN_MSGS__SRV__DETAIL__SLAM_INTERFACE__BUILDER_HPP_

#include "clean_msgs/srv/detail/slam_interface__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_SlamInterface_Request_poses
{
public:
  explicit Init_SlamInterface_Request_poses(::clean_msgs::srv::SlamInterface_Request & msg)
  : msg_(msg)
  {}
  ::clean_msgs::srv::SlamInterface_Request poses(::clean_msgs::srv::SlamInterface_Request::_poses_type arg)
  {
    msg_.poses = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::SlamInterface_Request msg_;
};

class Init_SlamInterface_Request_command
{
public:
  explicit Init_SlamInterface_Request_command(::clean_msgs::srv::SlamInterface_Request & msg)
  : msg_(msg)
  {}
  Init_SlamInterface_Request_poses command(::clean_msgs::srv::SlamInterface_Request::_command_type arg)
  {
    msg_.command = std::move(arg);
    return Init_SlamInterface_Request_poses(msg_);
  }

private:
  ::clean_msgs::srv::SlamInterface_Request msg_;
};

class Init_SlamInterface_Request_id
{
public:
  Init_SlamInterface_Request_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SlamInterface_Request_command id(::clean_msgs::srv::SlamInterface_Request::_id_type arg)
  {
    msg_.id = std::move(arg);
    return Init_SlamInterface_Request_command(msg_);
  }

private:
  ::clean_msgs::srv::SlamInterface_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::SlamInterface_Request>()
{
  return clean_msgs::srv::builder::Init_SlamInterface_Request_id();
}

}  // namespace clean_msgs


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_SlamInterface_Response_result
{
public:
  Init_SlamInterface_Response_result()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::clean_msgs::srv::SlamInterface_Response result(::clean_msgs::srv::SlamInterface_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::SlamInterface_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::SlamInterface_Response>()
{
  return clean_msgs::srv::builder::Init_SlamInterface_Response_result();
}

}  // namespace clean_msgs

#endif  // CLEAN_MSGS__SRV__DETAIL__SLAM_INTERFACE__BUILDER_HPP_
