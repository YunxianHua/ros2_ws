// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from clean_msgs:srv/GetAgiBotVersion.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__GET_AGI_BOT_VERSION__STRUCT_HPP_
#define CLEAN_MSGS__SRV__DETAIL__GET_AGI_BOT_VERSION__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__clean_msgs__srv__GetAgiBotVersion_Request __attribute__((deprecated))
#else
# define DEPRECATED__clean_msgs__srv__GetAgiBotVersion_Request __declspec(deprecated)
#endif

namespace clean_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct GetAgiBotVersion_Request_
{
  using Type = GetAgiBotVersion_Request_<ContainerAllocator>;

  explicit GetAgiBotVersion_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->cmd = 0ul;
    }
  }

  explicit GetAgiBotVersion_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->cmd = 0ul;
    }
  }

  // field types and members
  using _cmd_type =
    uint32_t;
  _cmd_type cmd;

  // setters for named parameter idiom
  Type & set__cmd(
    const uint32_t & _arg)
  {
    this->cmd = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint32_t GET_AGIBOT_VERSION =
    1u;

  // pointer types
  using RawPtr =
    clean_msgs::srv::GetAgiBotVersion_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const clean_msgs::srv::GetAgiBotVersion_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<clean_msgs::srv::GetAgiBotVersion_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<clean_msgs::srv::GetAgiBotVersion_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::GetAgiBotVersion_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::GetAgiBotVersion_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::GetAgiBotVersion_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::GetAgiBotVersion_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<clean_msgs::srv::GetAgiBotVersion_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<clean_msgs::srv::GetAgiBotVersion_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__clean_msgs__srv__GetAgiBotVersion_Request
    std::shared_ptr<clean_msgs::srv::GetAgiBotVersion_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__clean_msgs__srv__GetAgiBotVersion_Request
    std::shared_ptr<clean_msgs::srv::GetAgiBotVersion_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const GetAgiBotVersion_Request_ & other) const
  {
    if (this->cmd != other.cmd) {
      return false;
    }
    return true;
  }
  bool operator!=(const GetAgiBotVersion_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct GetAgiBotVersion_Request_

// alias to use template instance with default allocator
using GetAgiBotVersion_Request =
  clean_msgs::srv::GetAgiBotVersion_Request_<std::allocator<void>>;

// constant definitions
template<typename ContainerAllocator>
constexpr uint32_t GetAgiBotVersion_Request_<ContainerAllocator>::GET_AGIBOT_VERSION;

}  // namespace srv

}  // namespace clean_msgs


#ifndef _WIN32
# define DEPRECATED__clean_msgs__srv__GetAgiBotVersion_Response __attribute__((deprecated))
#else
# define DEPRECATED__clean_msgs__srv__GetAgiBotVersion_Response __declspec(deprecated)
#endif

namespace clean_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct GetAgiBotVersion_Response_
{
  using Type = GetAgiBotVersion_Response_<ContainerAllocator>;

  explicit GetAgiBotVersion_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->result = 0ul;
      this->product_version = "";
      this->soft_version = "";
      this->ip_address = "";
    }
  }

  explicit GetAgiBotVersion_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : product_version(_alloc),
    soft_version(_alloc),
    ip_address(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->result = 0ul;
      this->product_version = "";
      this->soft_version = "";
      this->ip_address = "";
    }
  }

  // field types and members
  using _result_type =
    uint32_t;
  _result_type result;
  using _product_version_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _product_version_type product_version;
  using _soft_version_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _soft_version_type soft_version;
  using _ip_address_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _ip_address_type ip_address;

  // setters for named parameter idiom
  Type & set__result(
    const uint32_t & _arg)
  {
    this->result = _arg;
    return *this;
  }
  Type & set__product_version(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->product_version = _arg;
    return *this;
  }
  Type & set__soft_version(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->soft_version = _arg;
    return *this;
  }
  Type & set__ip_address(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->ip_address = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    clean_msgs::srv::GetAgiBotVersion_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const clean_msgs::srv::GetAgiBotVersion_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<clean_msgs::srv::GetAgiBotVersion_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<clean_msgs::srv::GetAgiBotVersion_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::GetAgiBotVersion_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::GetAgiBotVersion_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::GetAgiBotVersion_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::GetAgiBotVersion_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<clean_msgs::srv::GetAgiBotVersion_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<clean_msgs::srv::GetAgiBotVersion_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__clean_msgs__srv__GetAgiBotVersion_Response
    std::shared_ptr<clean_msgs::srv::GetAgiBotVersion_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__clean_msgs__srv__GetAgiBotVersion_Response
    std::shared_ptr<clean_msgs::srv::GetAgiBotVersion_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const GetAgiBotVersion_Response_ & other) const
  {
    if (this->result != other.result) {
      return false;
    }
    if (this->product_version != other.product_version) {
      return false;
    }
    if (this->soft_version != other.soft_version) {
      return false;
    }
    if (this->ip_address != other.ip_address) {
      return false;
    }
    return true;
  }
  bool operator!=(const GetAgiBotVersion_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct GetAgiBotVersion_Response_

// alias to use template instance with default allocator
using GetAgiBotVersion_Response =
  clean_msgs::srv::GetAgiBotVersion_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace clean_msgs

namespace clean_msgs
{

namespace srv
{

struct GetAgiBotVersion
{
  using Request = clean_msgs::srv::GetAgiBotVersion_Request;
  using Response = clean_msgs::srv::GetAgiBotVersion_Response;
};

}  // namespace srv

}  // namespace clean_msgs

#endif  // CLEAN_MSGS__SRV__DETAIL__GET_AGI_BOT_VERSION__STRUCT_HPP_
