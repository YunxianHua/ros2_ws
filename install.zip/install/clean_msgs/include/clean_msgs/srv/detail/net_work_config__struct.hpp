// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from clean_msgs:srv/NetWorkConfig.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__NET_WORK_CONFIG__STRUCT_HPP_
#define CLEAN_MSGS__SRV__DETAIL__NET_WORK_CONFIG__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__clean_msgs__srv__NetWorkConfig_Request __attribute__((deprecated))
#else
# define DEPRECATED__clean_msgs__srv__NetWorkConfig_Request __declspec(deprecated)
#endif

namespace clean_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct NetWorkConfig_Request_
{
  using Type = NetWorkConfig_Request_<ContainerAllocator>;

  explicit NetWorkConfig_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->cmd = 0ul;
      this->type = 0ul;
      this->wireless_name = "";
      this->wireless_passwd = "";
    }
  }

  explicit NetWorkConfig_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : wireless_name(_alloc),
    wireless_passwd(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->cmd = 0ul;
      this->type = 0ul;
      this->wireless_name = "";
      this->wireless_passwd = "";
    }
  }

  // field types and members
  using _cmd_type =
    uint32_t;
  _cmd_type cmd;
  using _type_type =
    uint32_t;
  _type_type type;
  using _wireless_name_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _wireless_name_type wireless_name;
  using _wireless_passwd_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _wireless_passwd_type wireless_passwd;

  // setters for named parameter idiom
  Type & set__cmd(
    const uint32_t & _arg)
  {
    this->cmd = _arg;
    return *this;
  }
  Type & set__type(
    const uint32_t & _arg)
  {
    this->type = _arg;
    return *this;
  }
  Type & set__wireless_name(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->wireless_name = _arg;
    return *this;
  }
  Type & set__wireless_passwd(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->wireless_passwd = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint32_t NETWOTK_TYPE_CELLULAR =
    0u;
  static constexpr uint32_t NETWOTK_TYPE_WIRELESS =
    1u;
  static constexpr uint32_t NETWOTK_TYPE_HOTSPOT =
    2u;
  static constexpr uint32_t NETWORK_TYPE_ALL =
    3u;
  static constexpr uint32_t NETWORK_CMD_CLOSE =
    0u;
  static constexpr uint32_t NETWORK_CMD_OPEN =
    1u;
  static constexpr uint32_t NETWORK_CMD_GET =
    2u;
  static constexpr uint32_t NETWORK_CMD_WIRELESS_LIST =
    4u;
  static constexpr uint32_t NETWORK_CMD_CONNECT =
    5u;

  // pointer types
  using RawPtr =
    clean_msgs::srv::NetWorkConfig_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const clean_msgs::srv::NetWorkConfig_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<clean_msgs::srv::NetWorkConfig_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<clean_msgs::srv::NetWorkConfig_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::NetWorkConfig_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::NetWorkConfig_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::NetWorkConfig_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::NetWorkConfig_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<clean_msgs::srv::NetWorkConfig_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<clean_msgs::srv::NetWorkConfig_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__clean_msgs__srv__NetWorkConfig_Request
    std::shared_ptr<clean_msgs::srv::NetWorkConfig_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__clean_msgs__srv__NetWorkConfig_Request
    std::shared_ptr<clean_msgs::srv::NetWorkConfig_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const NetWorkConfig_Request_ & other) const
  {
    if (this->cmd != other.cmd) {
      return false;
    }
    if (this->type != other.type) {
      return false;
    }
    if (this->wireless_name != other.wireless_name) {
      return false;
    }
    if (this->wireless_passwd != other.wireless_passwd) {
      return false;
    }
    return true;
  }
  bool operator!=(const NetWorkConfig_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct NetWorkConfig_Request_

// alias to use template instance with default allocator
using NetWorkConfig_Request =
  clean_msgs::srv::NetWorkConfig_Request_<std::allocator<void>>;

// constant definitions
template<typename ContainerAllocator>
constexpr uint32_t NetWorkConfig_Request_<ContainerAllocator>::NETWOTK_TYPE_CELLULAR;
template<typename ContainerAllocator>
constexpr uint32_t NetWorkConfig_Request_<ContainerAllocator>::NETWOTK_TYPE_WIRELESS;
template<typename ContainerAllocator>
constexpr uint32_t NetWorkConfig_Request_<ContainerAllocator>::NETWOTK_TYPE_HOTSPOT;
template<typename ContainerAllocator>
constexpr uint32_t NetWorkConfig_Request_<ContainerAllocator>::NETWORK_TYPE_ALL;
template<typename ContainerAllocator>
constexpr uint32_t NetWorkConfig_Request_<ContainerAllocator>::NETWORK_CMD_CLOSE;
template<typename ContainerAllocator>
constexpr uint32_t NetWorkConfig_Request_<ContainerAllocator>::NETWORK_CMD_OPEN;
template<typename ContainerAllocator>
constexpr uint32_t NetWorkConfig_Request_<ContainerAllocator>::NETWORK_CMD_GET;
template<typename ContainerAllocator>
constexpr uint32_t NetWorkConfig_Request_<ContainerAllocator>::NETWORK_CMD_WIRELESS_LIST;
template<typename ContainerAllocator>
constexpr uint32_t NetWorkConfig_Request_<ContainerAllocator>::NETWORK_CMD_CONNECT;

}  // namespace srv

}  // namespace clean_msgs


// Include directives for member types
// Member 'wireless_infos'
#include "clean_msgs/msg/detail/wireless_network__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__clean_msgs__srv__NetWorkConfig_Response __attribute__((deprecated))
#else
# define DEPRECATED__clean_msgs__srv__NetWorkConfig_Response __declspec(deprecated)
#endif

namespace clean_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct NetWorkConfig_Response_
{
  using Type = NetWorkConfig_Response_<ContainerAllocator>;

  explicit NetWorkConfig_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->result = 0ul;
      this->cellular_net_enable = false;
      this->cellular_provider = 0ul;
      this->cellular_standard = 0ul;
      this->cellular_signal = 0ul;
      this->wireless_net_enable = false;
      this->hotspot_enable = false;
      this->hotspot_name = "";
      this->hostspot_passwd = "";
    }
  }

  explicit NetWorkConfig_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : hotspot_name(_alloc),
    hostspot_passwd(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->result = 0ul;
      this->cellular_net_enable = false;
      this->cellular_provider = 0ul;
      this->cellular_standard = 0ul;
      this->cellular_signal = 0ul;
      this->wireless_net_enable = false;
      this->hotspot_enable = false;
      this->hotspot_name = "";
      this->hostspot_passwd = "";
    }
  }

  // field types and members
  using _result_type =
    uint32_t;
  _result_type result;
  using _cellular_net_enable_type =
    bool;
  _cellular_net_enable_type cellular_net_enable;
  using _cellular_provider_type =
    uint32_t;
  _cellular_provider_type cellular_provider;
  using _cellular_standard_type =
    uint32_t;
  _cellular_standard_type cellular_standard;
  using _cellular_signal_type =
    uint32_t;
  _cellular_signal_type cellular_signal;
  using _wireless_net_enable_type =
    bool;
  _wireless_net_enable_type wireless_net_enable;
  using _wireless_infos_type =
    std::vector<clean_msgs::msg::WirelessNetwork_<ContainerAllocator>, typename ContainerAllocator::template rebind<clean_msgs::msg::WirelessNetwork_<ContainerAllocator>>::other>;
  _wireless_infos_type wireless_infos;
  using _hotspot_enable_type =
    bool;
  _hotspot_enable_type hotspot_enable;
  using _hotspot_name_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _hotspot_name_type hotspot_name;
  using _hostspot_passwd_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _hostspot_passwd_type hostspot_passwd;

  // setters for named parameter idiom
  Type & set__result(
    const uint32_t & _arg)
  {
    this->result = _arg;
    return *this;
  }
  Type & set__cellular_net_enable(
    const bool & _arg)
  {
    this->cellular_net_enable = _arg;
    return *this;
  }
  Type & set__cellular_provider(
    const uint32_t & _arg)
  {
    this->cellular_provider = _arg;
    return *this;
  }
  Type & set__cellular_standard(
    const uint32_t & _arg)
  {
    this->cellular_standard = _arg;
    return *this;
  }
  Type & set__cellular_signal(
    const uint32_t & _arg)
  {
    this->cellular_signal = _arg;
    return *this;
  }
  Type & set__wireless_net_enable(
    const bool & _arg)
  {
    this->wireless_net_enable = _arg;
    return *this;
  }
  Type & set__wireless_infos(
    const std::vector<clean_msgs::msg::WirelessNetwork_<ContainerAllocator>, typename ContainerAllocator::template rebind<clean_msgs::msg::WirelessNetwork_<ContainerAllocator>>::other> & _arg)
  {
    this->wireless_infos = _arg;
    return *this;
  }
  Type & set__hotspot_enable(
    const bool & _arg)
  {
    this->hotspot_enable = _arg;
    return *this;
  }
  Type & set__hotspot_name(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->hotspot_name = _arg;
    return *this;
  }
  Type & set__hostspot_passwd(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->hostspot_passwd = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    clean_msgs::srv::NetWorkConfig_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const clean_msgs::srv::NetWorkConfig_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<clean_msgs::srv::NetWorkConfig_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<clean_msgs::srv::NetWorkConfig_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::NetWorkConfig_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::NetWorkConfig_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::NetWorkConfig_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::NetWorkConfig_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<clean_msgs::srv::NetWorkConfig_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<clean_msgs::srv::NetWorkConfig_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__clean_msgs__srv__NetWorkConfig_Response
    std::shared_ptr<clean_msgs::srv::NetWorkConfig_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__clean_msgs__srv__NetWorkConfig_Response
    std::shared_ptr<clean_msgs::srv::NetWorkConfig_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const NetWorkConfig_Response_ & other) const
  {
    if (this->result != other.result) {
      return false;
    }
    if (this->cellular_net_enable != other.cellular_net_enable) {
      return false;
    }
    if (this->cellular_provider != other.cellular_provider) {
      return false;
    }
    if (this->cellular_standard != other.cellular_standard) {
      return false;
    }
    if (this->cellular_signal != other.cellular_signal) {
      return false;
    }
    if (this->wireless_net_enable != other.wireless_net_enable) {
      return false;
    }
    if (this->wireless_infos != other.wireless_infos) {
      return false;
    }
    if (this->hotspot_enable != other.hotspot_enable) {
      return false;
    }
    if (this->hotspot_name != other.hotspot_name) {
      return false;
    }
    if (this->hostspot_passwd != other.hostspot_passwd) {
      return false;
    }
    return true;
  }
  bool operator!=(const NetWorkConfig_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct NetWorkConfig_Response_

// alias to use template instance with default allocator
using NetWorkConfig_Response =
  clean_msgs::srv::NetWorkConfig_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace clean_msgs

namespace clean_msgs
{

namespace srv
{

struct NetWorkConfig
{
  using Request = clean_msgs::srv::NetWorkConfig_Request;
  using Response = clean_msgs::srv::NetWorkConfig_Response;
};

}  // namespace srv

}  // namespace clean_msgs

#endif  // CLEAN_MSGS__SRV__DETAIL__NET_WORK_CONFIG__STRUCT_HPP_
