// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from clean_msgs:srv/DevelopMode.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__DEVELOP_MODE__BUILDER_HPP_
#define CLEAN_MSGS__SRV__DETAIL__DEVELOP_MODE__BUILDER_HPP_

#include "clean_msgs/srv/detail/develop_mode__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_DevelopMode_Request_config_info
{
public:
  explicit Init_DevelopMode_Request_config_info(::clean_msgs::srv::DevelopMode_Request & msg)
  : msg_(msg)
  {}
  ::clean_msgs::srv::DevelopMode_Request config_info(::clean_msgs::srv::DevelopMode_Request::_config_info_type arg)
  {
    msg_.config_info = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::DevelopMode_Request msg_;
};

class Init_DevelopMode_Request_cmd
{
public:
  Init_DevelopMode_Request_cmd()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_DevelopMode_Request_config_info cmd(::clean_msgs::srv::DevelopMode_Request::_cmd_type arg)
  {
    msg_.cmd = std::move(arg);
    return Init_DevelopMode_Request_config_info(msg_);
  }

private:
  ::clean_msgs::srv::DevelopMode_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::DevelopMode_Request>()
{
  return clean_msgs::srv::builder::Init_DevelopMode_Request_cmd();
}

}  // namespace clean_msgs


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_DevelopMode_Response_config_infos
{
public:
  explicit Init_DevelopMode_Response_config_infos(::clean_msgs::srv::DevelopMode_Response & msg)
  : msg_(msg)
  {}
  ::clean_msgs::srv::DevelopMode_Response config_infos(::clean_msgs::srv::DevelopMode_Response::_config_infos_type arg)
  {
    msg_.config_infos = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::DevelopMode_Response msg_;
};

class Init_DevelopMode_Response_result
{
public:
  Init_DevelopMode_Response_result()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_DevelopMode_Response_config_infos result(::clean_msgs::srv::DevelopMode_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return Init_DevelopMode_Response_config_infos(msg_);
  }

private:
  ::clean_msgs::srv::DevelopMode_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::DevelopMode_Response>()
{
  return clean_msgs::srv::builder::Init_DevelopMode_Response_result();
}

}  // namespace clean_msgs

#endif  // CLEAN_MSGS__SRV__DETAIL__DEVELOP_MODE__BUILDER_HPP_
