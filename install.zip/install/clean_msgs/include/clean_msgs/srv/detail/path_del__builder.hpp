// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from clean_msgs:srv/PathDel.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__PATH_DEL__BUILDER_HPP_
#define CLEAN_MSGS__SRV__DETAIL__PATH_DEL__BUILDER_HPP_

#include "clean_msgs/srv/detail/path_del__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_PathDel_Request_map_id
{
public:
  explicit Init_PathDel_Request_map_id(::clean_msgs::srv::PathDel_Request & msg)
  : msg_(msg)
  {}
  ::clean_msgs::srv::PathDel_Request map_id(::clean_msgs::srv::PathDel_Request::_map_id_type arg)
  {
    msg_.map_id = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::PathDel_Request msg_;
};

class Init_PathDel_Request_id
{
public:
  Init_PathDel_Request_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_PathDel_Request_map_id id(::clean_msgs::srv::PathDel_Request::_id_type arg)
  {
    msg_.id = std::move(arg);
    return Init_PathDel_Request_map_id(msg_);
  }

private:
  ::clean_msgs::srv::PathDel_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::PathDel_Request>()
{
  return clean_msgs::srv::builder::Init_PathDel_Request_id();
}

}  // namespace clean_msgs


namespace clean_msgs
{

namespace srv
{

namespace builder
{

class Init_PathDel_Response_result
{
public:
  Init_PathDel_Response_result()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::clean_msgs::srv::PathDel_Response result(::clean_msgs::srv::PathDel_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return std::move(msg_);
  }

private:
  ::clean_msgs::srv::PathDel_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::clean_msgs::srv::PathDel_Response>()
{
  return clean_msgs::srv::builder::Init_PathDel_Response_result();
}

}  // namespace clean_msgs

#endif  // CLEAN_MSGS__SRV__DETAIL__PATH_DEL__BUILDER_HPP_
