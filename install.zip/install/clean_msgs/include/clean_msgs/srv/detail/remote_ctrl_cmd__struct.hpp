// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from clean_msgs:srv/RemoteCtrlCmd.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DETAIL__REMOTE_CTRL_CMD__STRUCT_HPP_
#define CLEAN_MSGS__SRV__DETAIL__REMOTE_CTRL_CMD__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__clean_msgs__srv__RemoteCtrlCmd_Request __attribute__((deprecated))
#else
# define DEPRECATED__clean_msgs__srv__RemoteCtrlCmd_Request __declspec(deprecated)
#endif

namespace clean_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct RemoteCtrlCmd_Request_
{
  using Type = RemoteCtrlCmd_Request_<ContainerAllocator>;

  explicit RemoteCtrlCmd_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->cmd_type = 0ul;
      this->time_stamp1 = 0ull;
      this->time_stamp2 = 0ull;
      this->session_id = "";
      this->direction = 0ul;
      this->turning = 0ul;
      this->linear = 0.0f;
      this->angle = 0.0f;
    }
  }

  explicit RemoteCtrlCmd_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : session_id(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->cmd_type = 0ul;
      this->time_stamp1 = 0ull;
      this->time_stamp2 = 0ull;
      this->session_id = "";
      this->direction = 0ul;
      this->turning = 0ul;
      this->linear = 0.0f;
      this->angle = 0.0f;
    }
  }

  // field types and members
  using _cmd_type_type =
    uint32_t;
  _cmd_type_type cmd_type;
  using _time_stamp1_type =
    uint64_t;
  _time_stamp1_type time_stamp1;
  using _time_stamp2_type =
    uint64_t;
  _time_stamp2_type time_stamp2;
  using _session_id_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _session_id_type session_id;
  using _direction_type =
    uint32_t;
  _direction_type direction;
  using _turning_type =
    uint32_t;
  _turning_type turning;
  using _linear_type =
    float;
  _linear_type linear;
  using _angle_type =
    float;
  _angle_type angle;

  // setters for named parameter idiom
  Type & set__cmd_type(
    const uint32_t & _arg)
  {
    this->cmd_type = _arg;
    return *this;
  }
  Type & set__time_stamp1(
    const uint64_t & _arg)
  {
    this->time_stamp1 = _arg;
    return *this;
  }
  Type & set__time_stamp2(
    const uint64_t & _arg)
  {
    this->time_stamp2 = _arg;
    return *this;
  }
  Type & set__session_id(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->session_id = _arg;
    return *this;
  }
  Type & set__direction(
    const uint32_t & _arg)
  {
    this->direction = _arg;
    return *this;
  }
  Type & set__turning(
    const uint32_t & _arg)
  {
    this->turning = _arg;
    return *this;
  }
  Type & set__linear(
    const float & _arg)
  {
    this->linear = _arg;
    return *this;
  }
  Type & set__angle(
    const float & _arg)
  {
    this->angle = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint32_t REMOTE_CONTROL_TYPE_START =
    1u;
  static constexpr uint32_t REMOTE_CONTROL_TYPE_START_COMP =
    2u;
  static constexpr uint32_t REMOTE_CONTROL_TYPE_CMD =
    3u;

  // pointer types
  using RawPtr =
    clean_msgs::srv::RemoteCtrlCmd_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const clean_msgs::srv::RemoteCtrlCmd_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<clean_msgs::srv::RemoteCtrlCmd_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<clean_msgs::srv::RemoteCtrlCmd_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::RemoteCtrlCmd_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::RemoteCtrlCmd_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::RemoteCtrlCmd_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::RemoteCtrlCmd_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<clean_msgs::srv::RemoteCtrlCmd_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<clean_msgs::srv::RemoteCtrlCmd_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__clean_msgs__srv__RemoteCtrlCmd_Request
    std::shared_ptr<clean_msgs::srv::RemoteCtrlCmd_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__clean_msgs__srv__RemoteCtrlCmd_Request
    std::shared_ptr<clean_msgs::srv::RemoteCtrlCmd_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const RemoteCtrlCmd_Request_ & other) const
  {
    if (this->cmd_type != other.cmd_type) {
      return false;
    }
    if (this->time_stamp1 != other.time_stamp1) {
      return false;
    }
    if (this->time_stamp2 != other.time_stamp2) {
      return false;
    }
    if (this->session_id != other.session_id) {
      return false;
    }
    if (this->direction != other.direction) {
      return false;
    }
    if (this->turning != other.turning) {
      return false;
    }
    if (this->linear != other.linear) {
      return false;
    }
    if (this->angle != other.angle) {
      return false;
    }
    return true;
  }
  bool operator!=(const RemoteCtrlCmd_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct RemoteCtrlCmd_Request_

// alias to use template instance with default allocator
using RemoteCtrlCmd_Request =
  clean_msgs::srv::RemoteCtrlCmd_Request_<std::allocator<void>>;

// constant definitions
template<typename ContainerAllocator>
constexpr uint32_t RemoteCtrlCmd_Request_<ContainerAllocator>::REMOTE_CONTROL_TYPE_START;
template<typename ContainerAllocator>
constexpr uint32_t RemoteCtrlCmd_Request_<ContainerAllocator>::REMOTE_CONTROL_TYPE_START_COMP;
template<typename ContainerAllocator>
constexpr uint32_t RemoteCtrlCmd_Request_<ContainerAllocator>::REMOTE_CONTROL_TYPE_CMD;

}  // namespace srv

}  // namespace clean_msgs


#ifndef _WIN32
# define DEPRECATED__clean_msgs__srv__RemoteCtrlCmd_Response __attribute__((deprecated))
#else
# define DEPRECATED__clean_msgs__srv__RemoteCtrlCmd_Response __declspec(deprecated)
#endif

namespace clean_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct RemoteCtrlCmd_Response_
{
  using Type = RemoteCtrlCmd_Response_<ContainerAllocator>;

  explicit RemoteCtrlCmd_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->result = 0ul;
      this->time_stamp = 0ull;
      this->session_id = "";
    }
  }

  explicit RemoteCtrlCmd_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : session_id(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->result = 0ul;
      this->time_stamp = 0ull;
      this->session_id = "";
    }
  }

  // field types and members
  using _result_type =
    uint32_t;
  _result_type result;
  using _time_stamp_type =
    uint64_t;
  _time_stamp_type time_stamp;
  using _session_id_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _session_id_type session_id;

  // setters for named parameter idiom
  Type & set__result(
    const uint32_t & _arg)
  {
    this->result = _arg;
    return *this;
  }
  Type & set__time_stamp(
    const uint64_t & _arg)
  {
    this->time_stamp = _arg;
    return *this;
  }
  Type & set__session_id(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->session_id = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    clean_msgs::srv::RemoteCtrlCmd_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const clean_msgs::srv::RemoteCtrlCmd_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<clean_msgs::srv::RemoteCtrlCmd_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<clean_msgs::srv::RemoteCtrlCmd_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::RemoteCtrlCmd_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::RemoteCtrlCmd_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      clean_msgs::srv::RemoteCtrlCmd_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<clean_msgs::srv::RemoteCtrlCmd_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<clean_msgs::srv::RemoteCtrlCmd_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<clean_msgs::srv::RemoteCtrlCmd_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__clean_msgs__srv__RemoteCtrlCmd_Response
    std::shared_ptr<clean_msgs::srv::RemoteCtrlCmd_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__clean_msgs__srv__RemoteCtrlCmd_Response
    std::shared_ptr<clean_msgs::srv::RemoteCtrlCmd_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const RemoteCtrlCmd_Response_ & other) const
  {
    if (this->result != other.result) {
      return false;
    }
    if (this->time_stamp != other.time_stamp) {
      return false;
    }
    if (this->session_id != other.session_id) {
      return false;
    }
    return true;
  }
  bool operator!=(const RemoteCtrlCmd_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct RemoteCtrlCmd_Response_

// alias to use template instance with default allocator
using RemoteCtrlCmd_Response =
  clean_msgs::srv::RemoteCtrlCmd_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace clean_msgs

namespace clean_msgs
{

namespace srv
{

struct RemoteCtrlCmd
{
  using Request = clean_msgs::srv::RemoteCtrlCmd_Request;
  using Response = clean_msgs::srv::RemoteCtrlCmd_Response;
};

}  // namespace srv

}  // namespace clean_msgs

#endif  // CLEAN_MSGS__SRV__DETAIL__REMOTE_CTRL_CMD__STRUCT_HPP_
