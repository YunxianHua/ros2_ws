// generated from rosidl_generator_c/resource/idl.h.em
// with input from clean_msgs:srv/MapSyncFinishNotify.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__MAP_SYNC_FINISH_NOTIFY_H_
#define CLEAN_MSGS__SRV__MAP_SYNC_FINISH_NOTIFY_H_

#include "clean_msgs/srv/detail/map_sync_finish_notify__struct.h"
#include "clean_msgs/srv/detail/map_sync_finish_notify__functions.h"
#include "clean_msgs/srv/detail/map_sync_finish_notify__type_support.h"

#endif  // CLEAN_MSGS__SRV__MAP_SYNC_FINISH_NOTIFY_H_
