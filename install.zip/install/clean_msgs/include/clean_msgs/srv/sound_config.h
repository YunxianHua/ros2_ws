// generated from rosidl_generator_c/resource/idl.h.em
// with input from clean_msgs:srv/SoundConfig.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__SOUND_CONFIG_H_
#define CLEAN_MSGS__SRV__SOUND_CONFIG_H_

#include "clean_msgs/srv/detail/sound_config__struct.h"
#include "clean_msgs/srv/detail/sound_config__functions.h"
#include "clean_msgs/srv/detail/sound_config__type_support.h"

#endif  // CLEAN_MSGS__SRV__SOUND_CONFIG_H_
