// generated from rosidl_generator_c/resource/idl.h.em
// with input from clean_msgs:srv/PathOpr.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__PATH_OPR_H_
#define CLEAN_MSGS__SRV__PATH_OPR_H_

#include "clean_msgs/srv/detail/path_opr__struct.h"
#include "clean_msgs/srv/detail/path_opr__functions.h"
#include "clean_msgs/srv/detail/path_opr__type_support.h"

#endif  // CLEAN_MSGS__SRV__PATH_OPR_H_
