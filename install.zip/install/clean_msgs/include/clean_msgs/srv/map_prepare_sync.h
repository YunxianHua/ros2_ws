// generated from rosidl_generator_c/resource/idl.h.em
// with input from clean_msgs:srv/MapPrepareSync.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__MAP_PREPARE_SYNC_H_
#define CLEAN_MSGS__SRV__MAP_PREPARE_SYNC_H_

#include "clean_msgs/srv/detail/map_prepare_sync__struct.h"
#include "clean_msgs/srv/detail/map_prepare_sync__functions.h"
#include "clean_msgs/srv/detail/map_prepare_sync__type_support.h"

#endif  // CLEAN_MSGS__SRV__MAP_PREPARE_SYNC_H_
