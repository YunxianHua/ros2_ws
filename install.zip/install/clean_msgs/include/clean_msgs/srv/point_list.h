// generated from rosidl_generator_c/resource/idl.h.em
// with input from clean_msgs:srv/PointList.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__POINT_LIST_H_
#define CLEAN_MSGS__SRV__POINT_LIST_H_

#include "clean_msgs/srv/detail/point_list__struct.h"
#include "clean_msgs/srv/detail/point_list__functions.h"
#include "clean_msgs/srv/detail/point_list__type_support.h"

#endif  // CLEAN_MSGS__SRV__POINT_LIST_H_
