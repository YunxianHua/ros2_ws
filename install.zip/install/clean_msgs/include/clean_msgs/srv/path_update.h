// generated from rosidl_generator_c/resource/idl.h.em
// with input from clean_msgs:srv/PathUpdate.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__PATH_UPDATE_H_
#define CLEAN_MSGS__SRV__PATH_UPDATE_H_

#include "clean_msgs/srv/detail/path_update__struct.h"
#include "clean_msgs/srv/detail/path_update__functions.h"
#include "clean_msgs/srv/detail/path_update__type_support.h"

#endif  // CLEAN_MSGS__SRV__PATH_UPDATE_H_
