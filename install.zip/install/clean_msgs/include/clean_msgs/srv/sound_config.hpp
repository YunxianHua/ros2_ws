// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__SOUND_CONFIG_HPP_
#define CLEAN_MSGS__SRV__SOUND_CONFIG_HPP_

#include "clean_msgs/srv/detail/sound_config__struct.hpp"
#include "clean_msgs/srv/detail/sound_config__builder.hpp"
#include "clean_msgs/srv/detail/sound_config__traits.hpp"
#include "clean_msgs/srv/detail/sound_config__type_support.hpp"

#endif  // CLEAN_MSGS__SRV__SOUND_CONFIG_HPP_
