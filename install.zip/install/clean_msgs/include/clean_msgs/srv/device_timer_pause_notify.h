// generated from rosidl_generator_c/resource/idl.h.em
// with input from clean_msgs:srv/DeviceTimerPauseNotify.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__DEVICE_TIMER_PAUSE_NOTIFY_H_
#define CLEAN_MSGS__SRV__DEVICE_TIMER_PAUSE_NOTIFY_H_

#include "clean_msgs/srv/detail/device_timer_pause_notify__struct.h"
#include "clean_msgs/srv/detail/device_timer_pause_notify__functions.h"
#include "clean_msgs/srv/detail/device_timer_pause_notify__type_support.h"

#endif  // CLEAN_MSGS__SRV__DEVICE_TIMER_PAUSE_NOTIFY_H_
