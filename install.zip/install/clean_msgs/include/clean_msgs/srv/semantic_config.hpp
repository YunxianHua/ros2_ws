// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__SEMANTIC_CONFIG_HPP_
#define CLEAN_MSGS__SRV__SEMANTIC_CONFIG_HPP_

#include "clean_msgs/srv/detail/semantic_config__struct.hpp"
#include "clean_msgs/srv/detail/semantic_config__builder.hpp"
#include "clean_msgs/srv/detail/semantic_config__traits.hpp"
#include "clean_msgs/srv/detail/semantic_config__type_support.hpp"

#endif  // CLEAN_MSGS__SRV__SEMANTIC_CONFIG_HPP_
