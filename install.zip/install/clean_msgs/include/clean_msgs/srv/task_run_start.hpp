// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__TASK_RUN_START_HPP_
#define CLEAN_MSGS__SRV__TASK_RUN_START_HPP_

#include "clean_msgs/srv/detail/task_run_start__struct.hpp"
#include "clean_msgs/srv/detail/task_run_start__builder.hpp"
#include "clean_msgs/srv/detail/task_run_start__traits.hpp"
#include "clean_msgs/srv/detail/task_run_start__type_support.hpp"

#endif  // CLEAN_MSGS__SRV__TASK_RUN_START_HPP_
