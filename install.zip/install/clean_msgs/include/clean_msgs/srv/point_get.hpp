// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__POINT_GET_HPP_
#define CLEAN_MSGS__SRV__POINT_GET_HPP_

#include "clean_msgs/srv/detail/point_get__struct.hpp"
#include "clean_msgs/srv/detail/point_get__builder.hpp"
#include "clean_msgs/srv/detail/point_get__traits.hpp"
#include "clean_msgs/srv/detail/point_get__type_support.hpp"

#endif  // CLEAN_MSGS__SRV__POINT_GET_HPP_
