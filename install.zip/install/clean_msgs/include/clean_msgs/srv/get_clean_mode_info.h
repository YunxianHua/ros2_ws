// generated from rosidl_generator_c/resource/idl.h.em
// with input from clean_msgs:srv/GetCleanModeInfo.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__GET_CLEAN_MODE_INFO_H_
#define CLEAN_MSGS__SRV__GET_CLEAN_MODE_INFO_H_

#include "clean_msgs/srv/detail/get_clean_mode_info__struct.h"
#include "clean_msgs/srv/detail/get_clean_mode_info__functions.h"
#include "clean_msgs/srv/detail/get_clean_mode_info__type_support.h"

#endif  // CLEAN_MSGS__SRV__GET_CLEAN_MODE_INFO_H_
