// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__SET_CLEAN_MODE_HPP_
#define CLEAN_MSGS__SRV__SET_CLEAN_MODE_HPP_

#include "clean_msgs/srv/detail/set_clean_mode__struct.hpp"
#include "clean_msgs/srv/detail/set_clean_mode__builder.hpp"
#include "clean_msgs/srv/detail/set_clean_mode__traits.hpp"
#include "clean_msgs/srv/detail/set_clean_mode__type_support.hpp"

#endif  // CLEAN_MSGS__SRV__SET_CLEAN_MODE_HPP_
