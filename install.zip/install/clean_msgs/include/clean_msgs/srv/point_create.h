// generated from rosidl_generator_c/resource/idl.h.em
// with input from clean_msgs:srv/PointCreate.idl
// generated code does not contain a copyright notice

#ifndef CLEAN_MSGS__SRV__POINT_CREATE_H_
#define CLEAN_MSGS__SRV__POINT_CREATE_H_

#include "clean_msgs/srv/detail/point_create__struct.h"
#include "clean_msgs/srv/detail/point_create__functions.h"
#include "clean_msgs/srv/detail/point_create__type_support.h"

#endif  // CLEAN_MSGS__SRV__POINT_CREATE_H_
